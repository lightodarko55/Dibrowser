# Popup Blocker + Third-Party Redirect Blocking — Fix Notes

## Why popups / redirects were still getting through (analysis)

The original code already had three layers (`PopupGuard` JS, `PopupGuard` native,
`PopupBlockerChromeClient`), but five holes made it look like "popup blocker not working":

1. **Any button tap explained ANY URL.**
   `PopupGuard.userExplains()` returned `true` for every navigation within 1.5 s of a tap on a
   *button* (`tapKind == 2`). Streaming/download sites redirect you the instant you tap
   Play / Download — so the "user gesture" check always passed and `location.href = 'ad-site'`
   sailed through.

2. **Popup URLs were loaded into the current tab instead of being blocked.**
   `PopupBlockerChromeClient.routeToSameTab()` captured the `window.open()` URL and, when the
   (always-passing, see #1) gesture check said "explained", called `parent.loadUrl(adUrl)` —
   replacing your page. That is exactly the "redirect on every tap" you saw.

3. **Server-side redirect chains were never blocked.**
   `shouldBlockNavigation()` returned `false` for every `request.isRedirect()` — so
   *tap play → redirector 302 → tracker 302 → spam site* chains passed freely.

4. **`intent://` / `market://` jumps launched other apps with no gesture check.**
   Any non-http URL went straight to `startActivity()` — silent bounces to the Play Store etc.

5. **Meta-refresh redirects in the page's own HTML were never checked.**
   The JS MutationObserver only sees metas *added by scripts*, not the ones in the initial HTML.

## What was changed

New setting: **Settings → Security and Privacy → "Block third-party redirects"**
(also in Feature Preference and in the browser ⋮ menu; default ON).

### 1. Strict button-tap rule (`PopupGuard.userExplains`)
When "Block third-party redirects" is ON, a tap on a button/play control only explains:
- the site you are already on, or
- a trusted sign-in/payment host (Google, Facebook, Apple, Microsoft, GitHub, PayPal, Discord,
  Twitter/X, Stripe — mirrored in the Java `AUTH_HOSTS` and the JS `AUTH` regex).

Any other cross-site jump from a button tap is now refused with
"Third-party redirect blocked". One tap can also only explain one navigation now
(`tapConsumed`).

### 2. Popups no longer load into the current tab (`PopupBlockerChromeClient.routeToSameTab`)
A `window.open()`/`target=_blank` that the user's actual link does not explain is now refused
outright (`onRedirectBlocked` → "Third-party redirect blocked") instead of hijacking the tab.
Real `<a target="_blank">` links still open normally (in the same tab, as before).

### 3. Redirect-chain cutoff (`PopupGuard.shouldBlockNavigation`)
- Known ad/tracker hosts are refused **even mid-chain** (previously a redirect hop could never
  be blocked at all).
- More than two consecutive server-side redirects that each leave the current site are cut off.
  Short chains still work (bit.ly and friends), and the counter resets on every committed page.
- Same-site navigation is always allowed, as before.

### 4. Silent external-app jumps blocked (`MainActivity.shouldOverrideUrlLoading`)
`intent://`, `market://`, `mailto://`… only fire `startActivity()` when the navigation has a
real user gesture. Non-gesture app jumps are refused.

### 5. Initial-HTML meta refresh now scanned (JS in `PopupGuard`)
`scanMetas()` runs at document start and again on DOMContentLoaded, so a
`<meta http-equiv=refresh>` that ships with the page is removed too.

### Other notes
- Two independent switches now drive one guard: "Block popups" controls the JS layer
  (window.open/overlay/synthetic-click guards); "Block third-party redirects" controls the
  strict native rules. Either one being ON keeps the guard alive.
- If a site you trust legitimately needs a cross-site button redirect, turn
  "Block third-party redirects" off for that session from the ⋮ menu.

Files changed: `Prefs.java`, `PopupGuard.java`, `PopupBlockerChromeClient.java`,
`MainActivity.java`, `res/menu/browser_menu.xml`.
