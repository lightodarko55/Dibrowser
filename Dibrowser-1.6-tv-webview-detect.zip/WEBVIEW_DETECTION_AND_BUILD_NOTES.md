# Dibrowser 1.6-tv+ - Gradle wrapper, WebView-engine auto-detection, faster startup

## 1. Gradle wrapper added (what you asked for "to build")
Android Studio needs `gradlew` / `gradlew.bat` / `gradle/wrapper/gradle-wrapper.properties`
(+ the small `gradle-wrapper.jar`) at the project root to build without you having a matching
Gradle version installed separately - these were missing from the zip, so Studio would have
failed the initial sync ("Gradle wrapper is missing"). Added, pinned to **Gradle 8.7**, which is
the minimum version `com.android.application` 8.6.1 (already in `build.gradle`) requires.

Open the project root (the folder with `settings.gradle`) in Android Studio - it will now sync
on its own. First sync still needs internet (Google's Maven + Maven Central) to pull the AGP,
media3 and NextLib artifacts.

## 2. Automatic Chrome / System WebView detection (`WebViewProvider.java`, new)
Android's WebView is a single OS-wide component (sometimes "Android System WebView", sometimes
the Chrome app itself on devices where Chrome is set as the provider) - an app can't swap engines
at runtime, only read which one is active and react to it. That's what was added:

* On startup, `WebViewProvider.detect()` calls `WebViewCompat.getCurrentWebViewPackage()` (the
  androidx.webkit API already a dependency here) to get the provider's package name + version.
* If the major version looks old (< 90) or the engine can't be identified reliably, the app
  **automatically drops into the existing lightweight/TV profile** (`lite = true`) - the same
  profile already used for TV boxes and low-RAM devices - instead of silently staying slow.
* A one-time dialog ("Browser engine is out of date") offers a direct **Update** button that
  opens the provider's Play Store page (falls back to the Play Store web page if the Play Store
  app isn't installed, e.g. some TV boxes). Dismissing it or updating is remembered per engine
  version, so it won't nag again until the engine version actually changes.
* **Settings > About** now also shows a live "Browser engine" row (e.g. "Chrome 128.0.6613.40" or
  "Android System WebView 118.0..."), tappable to jump to its Play Store listing any time.

This directly targets the "Mobile works fine; TV lags and crashes on websites" symptom from the
earlier notes: on a lot of cheap TV boxes the actual cause is a years-old WebView component, not
the app - this surfaces that and gives a one-tap fix instead of a silent slowdown.

## 3. A little faster
* **Safe Browsing disabled** (manifest `meta-data` + `WebSettingsCompat.setSafeBrowsingEnabled`):
  WebView's own Safe Browsing feature does a network round-trip the first time a page loads after
  install/update. The app already runs its own ad/tracker/popup blocking (`AdBlocker`,
  `PopupGuard`), so this is a free, measurable shave off the first page load - most noticeable on
  a TV box's weaker Wi-Fi.
* `gradle.properties`: `org.gradle.caching=true` (re-uses unchanged build outputs - faster repeat
  builds in Android Studio) and `org.gradle.daemon=true` (keeps the Gradle daemon warm between
  builds). `org.gradle.jvmargs` bumped from 1024m to 1536m heap - still well within a modest
  dev machine, removes a class of "Gradle ran out of memory, rebuild everything" slow builds.
* These are build/startup-time changes only - no change to the existing popup blocker, ad
  blocker, or the cache-first `goBackFast()`/`goForwardFast()` instant back/forward, which were
  already in place from the 1.6-tv notes.

Files touched: `app/src/main/java/com/dibrowser/app/WebViewProvider.java` (new),
`MainActivity.java`, `Prefs.java`, `AndroidManifest.xml`, `gradle.properties`,
plus the new `gradlew`, `gradlew.bat`, `gradle/wrapper/*`.

## 4. Follow-up: "make it select Chrome" is not something any app can do
A later ask was to have the app auto-select Chrome instead of "Android System WebView". That's
not possible from app code on any Android version - there is no API for an app to set which
package renders WebView content. The OS owns that choice entirely:
* On Android 7-9, a human can pick between installed providers at
  **Developer options > WebView implementation**.
* On Android 10+, most manufacturers (and essentially all TV boxes) removed that picker - the OS
  auto-selects whichever eligible, enabled provider has the newest version code, with no user or
  app override at all.
* "Android System WebView" showing up is not itself a defect: on current Android it's built from
  the same Blink/V8 engine as Chrome (Google's "Project Trichrome") and is auto-updated through
  the Play Store exactly like Chrome is - only the *version* actually matters for compatibility.

What changed instead (`WebViewProvider.java`, `MainActivity.java`):
* Settings > About > "Browser engine" and the out-of-date dialog now open an **Options** dialog
  with the two things that genuinely exist: a direct Play Store link to update whichever engine is
  currently active, and a shortcut into Android's own Developer options screen (where the
  WebView-implementation picker lives on the older Android versions that still have it).
* The in-app copy says plainly that this is an OS-level setting Dibrowser can't override, instead
  of implying a working "switch to Chrome" button that wouldn't actually do anything.
