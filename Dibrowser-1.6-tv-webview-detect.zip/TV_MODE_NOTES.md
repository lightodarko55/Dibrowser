# Dibrowser 1.1-tv - what changed

## Build fix
* `AndroidManifest.xml` now has `package="com.dibrowser.app"` (fixes
  `<manifest> does not have package attribute`). `namespace` is still set in `app/build.gradle`.
* Added the missing `gradle.properties` (`android.useAndroidX=true` is required) and `app/proguard-rules.pro`.
* Removed unused libraries (leanback, media3-rtsp) -> smaller APK, less RAM at start-up.
* `lint` can no longer abort an APK build.

## TV mode (Settings > Change User Agent > "TV mode (low RAM, smooth)")
Picked automatically on first start when the device is a TV / has no touchscreen. The same
"lite" profile is also used when Android reports a low-RAM device. It:
* uses this device's own WebView user agent (keeps the real Chrome version so websites don't send
  code an old WebView can't run), minus the `wv` / `Version/4.0` markers;
* turns off pinch-zoom, over-scroll glow, pull-to-refresh, autoplay, geolocation, off-screen pre-raster;
* no forced hardware layer on the WebView (saves a full-screen texture of RAM);
* force-dark is OFF by default on TV (it is expensive on weak GPUs; can be turned on in Feature Preference);
* when you leave the browser page (Home / Settings ...) the web page is dropped (`about:blank`) and the
  WebView is paused, so it stops using RAM and CPU in the background;
* video player: small buffer (about 20 MB / 30 s instead of 100 MB+), 1080p cap, decoder fallback.

## Crash fixes
* **Renderer crash handler** (`onRenderProcessGone`, Android 8+): the WebView is rebuilt and the page
  reloaded instead of the whole app dying. After 3 crashes in 30 s you are sent Home with a message.
* **API 21-23 crash**: `hasGesture()` / `isRedirect()` need Android 7; now guarded (`Compat.java`).
* The activity is no longer restarted when the TV changes resolution / a remote connects
  (`configChanges` extended) - a restart used to rebuild the WebView.
* Ad/tracker host list grew from 23 to ~150 hosts: fewer heavy requests.

## Cursor (D-pad mouse)
* **Auto-hide after 5 seconds** without a key press (Cursor settings > "Hide cursor after 5 s of no use").
  First OK press while hidden only shows it again (no accidental click); arrows show and move it.
* New "Cursor size" (Small / Medium / Large), allocation-free drawing, edge-scroll left/right too.
* CH+/CH-/Page keys scroll a page; the remote's Menu key opens the browser menu.
* Cursor is enabled by default on first start on a TV.

## Build
Open the folder (the one with `settings.gradle`) in your build app. `compileSdk 34`, `minSdk 21`, AGP 8.5.0
(JDK 17). For an even smaller release APK set `minifyEnabled true` and `shrinkResources true`
in `app/build.gradle` (keep-rules already in `app/proguard-rules.pro`).
