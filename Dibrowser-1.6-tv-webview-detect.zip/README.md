# Dibrowser — Java, WebView-based

## UI (new)
Landscape/TV-first layout inspired by HiBrowser, built from original code and assets:
- **Left rail** — Home / Bookmark / History / IPTV / Settings. Icons only; expands to show
  labels while the D-pad focus is on it (or tap the logo to pin it open). Selected = dark
  circle, focused = light pill. Hidden while browsing.
- **Home** — search pill, round buttons (voice, QR scan, incognito, downloads, clear data,
  share) and a **Recommend** row of shortcut tiles (long-press to remove, "+" to add).
- **Bookmark / History / IPTV** — one shared list page (IPTV loads an M3U playlist URL and plays
  channels in the in-app player).
- **Settings** — rounded cards: On Startup, Customize Home Page, Search Engine, Change User
  Agent, Language, Age-related lock (PIN), Feature Preference (dialog), Cursor settings
  (dialog, D-pad mouse pointer), Security and Privacy, About.
- **Browser view** — slim top bar (home, back, forward, reload, address, bookmark, menu).

New files: `Prefs.java`, `Adapters.java`, `CursorView.java`; most new resources are
`res/drawable` (vector icons, shapes), `res/layout`, `res/values/{colors,themes,strings}.xml`.
New dependencies (see `app/build.gradle`): recyclerview, androidx.webkit, zxing-android-embedded.
Launcher icon uses your own `mipmap/ic_launcher` files.
Notes: cleartext (http) traffic is now allowed because many IPTV streams are http; the logo is
a placeholder vector (`drawable/ic_logo.xml`) — swap in your own branding.

---


Drop the `app/` folder's contents into your existing Android Studio project (or open this
folder directly as a new project — it's a complete minimal one).

## What's included
- `MainActivity.java` — WebView wiring, address bar, menu actions, TV back-handling
- `PopupBlockerChromeClient.java` — blocks `window.open()` / popup-window creation
- `VideoDetector.java` — DOM scan + MutationObserver (JS) + network-level sniffing (Java)
  for video URLs, including players that attach `<video>` late or stream via JS (HLS/DASH)
- `VideoPlayerActivity.java` — in-app player (Media3 ExoPlayer) opened when a detected
  video is tapped, with **Quality**, **Audio**, and **CC (captions)** buttons layered over
  the normal play/pause/seek controls
- `activity_main.xml`, `activity_video_player.xml`, `browser_menu.xml` — layouts + menu
- `AndroidManifest.xml` — permissions, **both** `LAUNCHER` and `LEANBACK_LAUNCHER` intent
  filters so the app installs and shows up on Android TV *and* phones/tablets
- `build.gradle` / `settings.gradle` — Gradle setup incl. Media3 ExoPlayer, minSdk 21

## In-app video player (Quality / Audio / Captions)
`VideoPlayerActivity` opens when you tap a detected video in the list. It uses Media3
ExoPlayer, which natively parses HLS (`.m3u8`) and DASH (`.mpd`) manifests — that's where
the quality ladder, alternate audio languages, and subtitle tracks actually come from (a
plain `.mp4` usually only has one of each, so the buttons just grey out for those).
- **Quality** — lists every video rendition in the stream (e.g. `1080p`, `720p`, `480p`) plus
  `Auto`; picking one pins ExoPlayer to that rendition via a `TrackSelectionOverride`,
  `Auto` clears the override and lets adaptive bitrate switching resume.
- **Audio** — lists alternate audio tracks (dubs/languages) when the stream has them.
- **CC** — toggles subtitles on/off; if more than one caption language is present it asks
  which one first. Off by default on open, matching typical player behavior.
If a given video only has one quality/audio/caption option, that button is disabled rather
than shown misleadingly as if there were a real choice.

## Why your current video detection misses videos (and how this fixes it)
Most simple "video finder" implementations only read the initial HTML for `<video src>`.
That breaks on:
1. **Players that build the `<video>` tag with JavaScript after the page loads** (most
   modern embeds). Fixed with a `MutationObserver` that re-scans on every DOM change.
2. **HLS/DASH players** (`.m3u8` / `.mpd`) that never put a direct file URL in the DOM at
   all — they stream segments via JS/MSE. Fixed by sniffing every network request in
   `shouldInterceptRequest` for media-looking URLs.
3. **Same-origin iframes** embedding the actual player. Fixed by recursing into
   `iframe.contentDocument` when same-origin (cross-origin iframes are not reachable from
   JS for security reasons — this is a browser-level restriction, not a bug).

## Popup blocking approach
`onCreateWindow()` is overridden to refuse creating a second WebView/window. A real user
tap on a link still works (it's redirected into the *same* WebView instead of a new
window), so normal navigation isn't broken — only scripted/non-gesture popups and
popunders are blocked. Toggle at runtime from the overflow menu.

## TV support notes
- The manifest advertises `android.software.leanback` as **not required**, so the same
  APK installs on phones, tablets, and TV.
- `LEANBACK_LAUNCHER` intent-filter makes it show up on the Android TV home screen.
- `tv_banner.xml` is a placeholder — Android TV requires a 320x180dp banner image; replace
  it with a real PNG in `res/drawable-xhdpi/tv_banner.png` before publishing.
- D-pad navigation works out of the box for the address bar and menu (standard Android
  focus system); the WebView itself uses its built-in D-pad-to-touch translation for
  simple sites. If you need a custom on-screen cursor for complex sites, that's a bigger
  follow-up feature — ask if you want that built out.

## Ad / popup / new-tab-popup blocking
- `AdBlocker.java` — host-based blocklist checked in `shouldInterceptRequest`; a match
  returns an empty response so the ad slot collapses instead of loading a blank box. Ships
  with a small seed list (`doubleclick.net`, `googlesyndication.com`, `popads.net`, etc.) —
  for real coverage, drop a maintained hosts file at `app/src/main/assets/adblock_hosts.txt`
  (one domain per line); it's picked up automatically if present.
- `PopupBlockerChromeClient.java` — refuses `onCreateWindow()`, which is exactly how a
  "new tab auto-opens on page load/click" popup gets created. A real user tap on a link is
  redirected into the *same* WebView instead of being blocked, so normal navigation still
  works — only scripted/non-gesture popups and popunders (the "new tab auto open" problem)
  are stopped. Toggle at runtime: overflow menu → "Toggle popup blocking".

## Download manager
`DownloadHandler.java`, wired via `webView.setDownloadListener(...)`. Any file download
(PDF, APK, image, etc.) shows a confirmation dialog — filename, size, available space,
Cancel/Download — then hands off to Android's own `DownloadManager`, which shows system
progress and a completion notification. `REQUEST_INSTALL_PACKAGES` permission is declared
for the "install after download" flow for APKs; wiring the actual post-download install
prompt (via `BroadcastReceiver` on `DownloadManager.ACTION_DOWNLOAD_COMPLETE` + a
`FileProvider` URI) is noted in the code as the next step if you want full auto-install —
ask and I'll add it.

## Privacy / incognito mode
`PrivacyModeManager.java`. Toggle from the overflow menu ("Toggle incognito mode"): while
active, cookies aren't persisted, and `webView.clearHistory()/clearCache()/clearFormData()`
plus `CookieManager.removeAllCookies()` and `WebStorage.deleteAllData()` run both on enable
and on disable (and again automatically in `onDestroy()` if you close the app mid-session),
so nothing survives the session. "Incognito history" menu item shows the in-session visited
list with a "Clear all" option — it only exists in memory and is wiped with the rest.

## Quick video access
A floating button (bottom-right, over the page) jumps straight to the detected-videos list
— same list as the "Videos" menu item, just one tap away without opening the overflow menu.

## TV support notes
- The manifest advertises `android.software.leanback` as **not required**, so the same
  APK installs on phones, tablets, and TV.
- `LEANBACK_LAUNCHER` intent-filter makes it show up on the Android TV home screen.
- `tv_banner.xml` is a placeholder — Android TV requires a 320x180dp banner image; replace
  it with a real PNG in `res/drawable-xhdpi/tv_banner.png` before publishing.
- **Spatial navigation (D-pad link traversal):** Chromium-based WebView already does this
  natively on devices with no touchscreen (i.e., Android TV) — arrow keys move focus
  between links/buttons on the page, DPAD_CENTER activates the focused one. Nothing extra
  needed for that baseline behavior. If you want an on-screen cursor overlay instead (like
  a mouse pointer you steer with the D-pad, for sites with poor native focus order), that's
  a separate, bigger feature — say the word and I'll build it.

## A note on scope
This clones the **feature set** you described (ad/popup blocking, new-tab-popup blocking,
download manager, privacy mode, video detection + in-app playback with quality/audio/CC,
TV support) as original code — not the Hi Browser name, logo, or exact UI chrome, and
nothing copied from its GitHub repo. Swap `strings.xml`'s `app_name` and the placeholder
launcher icon for your own branding whenever you're ready.

## Possible next additions
- Tabs (multiple WebView instances) for a tabbed-browsing UI rather than single-page.
- On-screen D-pad cursor overlay for TV (see spatial navigation note above).
- Wire the full APK auto-install-on-download-complete flow.
- A bundled, larger ad/tracker hosts list instead of the small seed list.

## Popup / redirect blocker (PopupGuard + PopupBlockerChromeClient)
Strict, user-gesture based (same idea as AdGuard Popup Blocker, original implementation):
- window.open, synthetic link clicks, form target=_blank, invisible click-hijack overlays and meta-refresh to other sites are blocked unless a real tap caused them.
- Native layer: no new tabs are ever created; cross-site top-frame navigations with no user gesture are cancelled.
- Toggle: Settings > Block popups.
