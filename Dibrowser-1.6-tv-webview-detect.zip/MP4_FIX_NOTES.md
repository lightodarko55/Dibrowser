# Dibrowser 1.4
Based on 1.1. HLS / DASH / Smooth play through the unchanged 1.1 path (initPlayer).
Plain files (mp4, webm, mkv, flv, 3gp, mov, ...) use a separate ladder (startProgressive):
 1. HttpURLConnection stack, page headers + cookies
 2. OkHttp stack (HTTP/2, modern TLS), non-WebView UA, Chromium Sec-Fetch headers
 3..8. other UA / Referer / cookie combinations, bare request
 then: embedded Chromium <video>, then Chromium opening the file URL directly with Referer.
 A "plain file" link that is really a playlist is retried as HLS.
Final error dialog shows the player error + browser-engine error.
New dependencies: media3-datasource-okhttp, okhttp, media3-exoplayer-smoothstreaming, media3-exoplayer-rtsp.
