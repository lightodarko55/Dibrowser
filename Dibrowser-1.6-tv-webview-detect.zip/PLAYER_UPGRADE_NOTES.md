# Dibrowser 1.5 - smart player upgrade

## The bug
`ERROR_CODE_DECODING_FAILED` (e.g. MKV from ANIMAHD) is a **decoder** error - the file downloads fine but the phone's
hardware codec rejects the video (often 10-bit HEVC) or audio (AC3 / E-AC3 / DTS) track. The old player treated every
error as a header problem, so it burned the 6-step header ladder ("Retrying with different headers... 3/6") and then
dropped into the WebView "compatibility player", which cannot play MKV either.

## What changed (VideoPlayerActivity.java)
* Decoder errors are classified (`isDecoderError`) and no longer use the header ladder.
* Stage 1: restart at the same position with **software decoders first** (custom `MediaCodecSelector`,
  `EXTENSION_RENDERER_MODE_PREFER`).
* Stage 2: if the *audio* decoder is the one failing, play the video **without sound** (toast tells the user).
* Still failing: clear message + **Open in other app** (system chooser, `video/*`) - VLC / MX / mpv.
* Header ladder now runs only for server / network refusals (HTTP errors, 2xxx IO errors).
* HLS/DASH path gets the same decoder recovery and resumes position.
* **Compatibility player removed**: WebView fallback, JS bridge, `loadDirectInWeb`, related imports/state.
* `versionName` 1.5-tv, `versionCode` 3.

## FFmpeg decoders - NOW ENABLED (VLC / MX Player style decoding), version 1.6-tv
Why VLC plays the file but this player did not: VLC and MX Player carry their own FFmpeg decoders, while the old
player could only use the phone's built-in codecs. NextLib adds FFmpeg software decoders to the same player:
audio AC3 / E-AC3 / DTS / TrueHD / FLAC / Opus / Vorbis / MP3 / AAC, video H.264 / HEVC (incl. 10-bit) / VP8 / VP9.

Changes (no UI, layout or option was touched):
* `app/build.gradle`: `nextlib-media3ext:1.7.1-0.9.0` added; every `androidx.media3:*` line moved from 1.4.1 to 1.7.1
  (NextLib's media3 part must match); `compileSdk 35` (media3 1.7 needs it, `targetSdk` stays 34);
  versionCode 4 / versionName 1.6-tv.
* root `build.gradle`: Android Gradle Plugin 8.5.0 -> 8.6.1 (first version that officially supports compileSdk 35;
  same Gradle requirement as 8.5.0).
* `VideoPlayerActivity.java`: no change needed to pick up the decoders (NextRenderersFactory is found by reflection).
  Added `newMediaSourceFactory()` - tolerant container parsing (constant-bitrate seeking, DTS and access-unit
  detection in MPEG-TS, non-IDR key frames) used by both play paths.

How it plays a file now: hardware decoder first (cheap on battery) -> if the phone cannot handle the format, FFmpeg is
used automatically -> if a decoder fails while playing, restart at the same position with FFmpeg/software first ->
if only the audio is the problem, play without sound -> last resort: "Open in other app".

Build needs: Android SDK platform 35 installed, internet for the first Gradle sync (Maven Central), APK grows ~10-20 MB.
GPL-3.0 applies to the bundled FFmpeg decoder.
Not covered by decoders (container support is separate): AVI, WMV/ASF, RealMedia - ExoPlayer cannot open these.
Newer NextLib (1.9.x-1.11.x) adds AV1 and fixes software video rotation but needs media3 1.9+/compileSdk 36 + newer AGP.
