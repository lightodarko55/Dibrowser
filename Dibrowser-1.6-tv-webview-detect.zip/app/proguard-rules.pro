# Only used when minifyEnabled is turned on in app/build.gradle.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.dibrowser.app.VideoDetector$JsBridge { *; }
-keep class com.dibrowser.app.PopupGuard { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-keep class io.github.anilbeesetti.nextlib.** { *; }
-dontwarn io.github.anilbeesetti.nextlib.**
