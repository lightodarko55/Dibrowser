package com.dibrowser.app;

import android.app.ActivityManager;
import android.app.UiModeManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Thin wrapper over SharedPreferences holding every user-facing setting + saved lists. */
public class Prefs {

    /** A titled URL (shortcut, bookmark, history item, IPTV channel). */
    public static final class Entry {
        public final String title;
        public final String url;

        public Entry(String title, String url) {
            this.title = title;
            this.url = url;
        }
    }

    public static final class Engine {
        public final String name;
        public final String letter;
        public final int color;
        public final String searchUrl; // query is appended

        Engine(String name, String letter, int color, String searchUrl) {
            this.name = name;
            this.letter = letter;
            this.color = color;
            this.searchUrl = searchUrl;
        }
    }

    public static final Engine[] ENGINES = {
            new Engine("Google", "G", 0xFF4285F4, "https://www.google.com/search?q="),
            new Engine("Bing", "B", 0xFF0F7B7B, "https://www.bing.com/search?q="),
            new Engine("DuckDuckGo", "D", 0xFFDE5833, "https://duckduckgo.com/?q="),
            new Engine("Yahoo", "Y", 0xFF6001D2, "https://search.yahoo.com/search?p="),
            new Engine("Brave", "B", 0xFFFB542B, "https://search.brave.com/search?q="),
    };

    public static final String TV_UA_MARKER = "@tv";

    /** {label, user-agent string}. Empty string = WebView's own default. */
    public static final String[][] USER_AGENTS = {
            {"Default (recommended)", ""},
            {"Desktop (Chrome)", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"},
            {"iPhone (Safari)", "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"},
            {"iPad (Safari)", "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"},
            // Marker value: MainActivity builds the real string from this device's own WebView UA
            // (keeps the true Chrome version, so sites don't ship JS the old WebView can't run).
            {"TV mode (low RAM, smooth)", TV_UA_MARKER},
    };

    public static final int UA_TV = USER_AGENTS.length - 1;

    public static final int[] CURSOR_SPEEDS = {8, 14, 24};
    public static final String[] CURSOR_SPEED_NAMES = {"Slow", "Normal", "Fast"};
    public static final float[] CURSOR_SIZES = {1.0f, 1.4f, 1.9f};
    public static final String[] CURSOR_SIZE_NAMES = {"Small", "Medium", "Large"};
    /** The pointer disappears after this long without a key press. */
    public static final long CURSOR_HIDE_MS = 5000;

    private static final String FILE = "browser_prefs";
    private static final int MAX_HISTORY = 300;

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
        adBlockOn = sp.getBoolean("ad_block", true);
    }

    /** True on Android TV / boxes without a touchscreen. */
    public static boolean isTvDevice(Context c) {
        try {
            UiModeManager um = (UiModeManager) c.getSystemService(Context.UI_MODE_SERVICE);
            if (um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        } catch (Exception ignored) {
        }
        return !c.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
    }

    /** True when the system itself says this is a low-RAM device (usually 1 GB or less). */
    public static boolean isLowRam(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            return am != null && am.isLowRamDevice();
        } catch (Exception e) {
            return false;
        }
    }

    /** Lite profile = TV box, low-RAM device, or the user picked the "TV mode" user agent. */
    public boolean liteMode(Context c) {
        return userAgentIndex() == UA_TV || isTvDevice(c) || isLowRam(c);
    }

    /**
     * Runs once: on a TV, start in TV mode with the heavy extras (force-dark) off. Anything the user
     * already chose is left alone.
     */
    public void applyTvDefaults(boolean tv) {
        if (sp.getBoolean("tv_defaults_done", false)) return;
        SharedPreferences.Editor e = sp.edit();
        if (tv) {
            if (!sp.contains("ua")) e.putInt("ua", UA_TV);
            if (!sp.contains("dark_mode")) e.putBoolean("dark_mode", false);
            if (!sp.contains("cursor")) e.putBoolean("cursor", true);
        }
        e.putBoolean("tv_defaults_done", true).apply();
    }

    // ---- simple values ----------------------------------------------------------------------
    public boolean startOnLastPage() { return sp.getBoolean("start_last", false); }
    public void setStartOnLastPage(boolean v) { sp.edit().putBoolean("start_last", v).apply(); }

    public String lastUrl() { return sp.getString("last_url", ""); }
    public void setLastUrl(String u) { sp.edit().putString("last_url", u).apply(); }

    public int engineIndex() {
        int i = sp.getInt("engine", 0);
        return (i >= 0 && i < ENGINES.length) ? i : 0;
    }
    public void setEngineIndex(int i) { sp.edit().putInt("engine", i).apply(); }
    public Engine engine() { return ENGINES[engineIndex()]; }

    public int userAgentIndex() {
        int i = sp.getInt("ua", 0);
        return (i >= 0 && i < USER_AGENTS.length) ? i : 0;
    }
    public void setUserAgentIndex(int i) { sp.edit().putInt("ua", i).apply(); }

    public boolean ageLock() { return sp.getBoolean("age_lock", false); }
    public String agePin() { return sp.getString("age_pin", ""); }
    public void setAgeLock(boolean on, String pin) {
        sp.edit().putBoolean("age_lock", on).putString("age_pin", on ? pin : "").apply();
    }

    public boolean videoControl() { return sp.getBoolean("video_control", true); }
    public void setVideoControl(boolean v) { sp.edit().putBoolean("video_control", v).apply(); }

    public boolean smartPlayer() { return sp.getBoolean("smart_player", true); }
    public void setSmartPlayer(boolean v) { sp.edit().putBoolean("smart_player", v).apply(); }

    public boolean darkMode() { return sp.getBoolean("dark_mode", true); }
    public void setDarkMode(boolean v) { sp.edit().putBoolean("dark_mode", v).apply(); }

    // cached: read from WebView's network threads for every single request
    private volatile boolean adBlockOn;
    public boolean adBlock() { return adBlockOn; }
    public void setAdBlock(boolean v) { adBlockOn = v; sp.edit().putBoolean("ad_block", v).apply(); }

    /** Per-site switch of the "Select Video to Play" detector (default: enabled everywhere). */
    public boolean videoDetectEnabled(String host) {
        return !sp.getStringSet("video_off_hosts", new java.util.HashSet<String>()).contains(host);
    }
    public void setVideoDetectEnabled(String host, boolean on) {
        java.util.Set<String> set = new java.util.HashSet<>(sp.getStringSet("video_off_hosts", new java.util.HashSet<String>()));
        if (on) set.remove(host); else set.add(host);
        sp.edit().putStringSet("video_off_hosts", set).apply();
    }

    public boolean popupBlock() { return sp.getBoolean("popup_block", true); }
    public void setPopupBlock(boolean v) { sp.edit().putBoolean("popup_block", v).apply(); }

    /** Strict third-party redirect blocking (tap-hijack / redirect-chain / silent app-jump). */
    public boolean redirectBlock() { return sp.getBoolean("redirect_block", true); }
    public void setRedirectBlock(boolean v) { sp.edit().putBoolean("redirect_block", v).apply(); }

    /** Last WebView-provider version string for which the "update your WebView" prompt was dismissed. */
    public String webViewWarningDismissedFor() { return sp.getString("webview_warn_dismissed", ""); }
    public void setWebViewWarningDismissedFor(String versionName) {
        sp.edit().putString("webview_warn_dismissed", versionName == null ? "" : versionName).apply();
    }

    public boolean cursorEnabled() { return sp.getBoolean("cursor", false); }
    public void setCursorEnabled(boolean v) { sp.edit().putBoolean("cursor", v).apply(); }

    public int cursorSpeedIndex() {
        int i = sp.getInt("cursor_speed", 1);
        return (i >= 0 && i < CURSOR_SPEEDS.length) ? i : 1;
    }
    public void setCursorSpeedIndex(int i) { sp.edit().putInt("cursor_speed", i).apply(); }

    public boolean cursorAutoHide() { return sp.getBoolean("cursor_autohide", true); }
    public void setCursorAutoHide(boolean v) { sp.edit().putBoolean("cursor_autohide", v).apply(); }

    public int cursorSizeIndex() {
        int i = sp.getInt("cursor_size", 1);
        return (i >= 0 && i < CURSOR_SIZES.length) ? i : 1;
    }
    public void setCursorSizeIndex(int i) { sp.edit().putInt("cursor_size", i).apply(); }

    public boolean giftSeen() { return sp.getBoolean("gift_seen", false); }
    public void setGiftSeen() { sp.edit().putBoolean("gift_seen", true).apply(); }

    public String iptvUrl() { return sp.getString("iptv_url", ""); }
    public void setIptvUrl(String u) { sp.edit().putString("iptv_url", u).apply(); }

    // ---- lists -------------------------------------------------------------------------------
    public List<Entry> shortcuts() {
        if (!sp.contains("shortcuts")) {
            List<Entry> d = new ArrayList<>();
            d.add(new Entry("YouTube", "https://www.youtube.com"));
            d.add(new Entry("Google", "https://www.google.com"));
            d.add(new Entry("TikTok", "https://www.tiktok.com"));
            d.add(new Entry("DuckDuckGo", "https://duckduckgo.com"));
            d.add(new Entry("Wikipedia", "https://www.wikipedia.org"));
            d.add(new Entry("Reddit", "https://www.reddit.com"));
            return d;
        }
        return read("shortcuts");
    }
    public void saveShortcuts(List<Entry> l) { write("shortcuts", l); }
    public void resetShortcuts() { sp.edit().remove("shortcuts").apply(); }

    public List<Entry> bookmarks() { return read("bookmarks"); }
    public void saveBookmarks(List<Entry> l) { write("bookmarks", l); }

    public boolean isBookmarked(String url) {
        for (Entry e : bookmarks()) if (e.url.equals(url)) return true;
        return false;
    }

    public List<Entry> history() { return read("history"); }
    public void clearHistory() { sp.edit().remove("history").apply(); }

    /** Newest first; consecutive duplicates collapse. */
    public void addHistory(String title, String url) {
        List<Entry> l = read("history");
        if (!l.isEmpty() && l.get(0).url.equals(url)) l.remove(0);
        l.add(0, new Entry(title == null || title.isEmpty() ? url : title, url));
        while (l.size() > MAX_HISTORY) l.remove(l.size() - 1);
        write("history", l);
    }

    public void saveHistory(List<Entry> l) { write("history", l); }

    // ---- json plumbing -----------------------------------------------------------------------
    private List<Entry> read(String key) {
        List<Entry> out = new ArrayList<>();
        String raw = sp.getString(key, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Entry(o.optString("t"), o.optString("u")));
            }
        } catch (JSONException ignored) {
        }
        return out;
    }

    private void write(String key, List<Entry> l) {
        JSONArray a = new JSONArray();
        try {
            for (Entry e : l) {
                JSONObject o = new JSONObject();
                o.put("t", e.title);
                o.put("u", e.url);
                a.put(o);
            }
        } catch (JSONException ignored) {
        }
        sp.edit().putString(key, a.toString()).apply();
    }
}
