package com.dibrowser.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Native half of the popup blocker (the JS half is {@link PopupGuard}).
 *
 * Requires WebSettings.setSupportMultipleWindows(true) and
 * setJavaScriptCanOpenWindowsAutomatically(false): the latter makes the engine itself refuse
 * every window.open() that is not directly caused by a tap; the former makes the engine call
 * {@link #onCreateWindow} (instead of silently navigating the current page) for the ones that are.
 *
 * Strict policy while blocking is ON:
 *  - no user gesture, or dialog-style window  -> refused
 *  - gesture: the URL is captured with a throw-away WebView, checked against the ad list,
 *    rate-limited (one per 1.5 s) and then loaded in the SAME tab. A new tab/window is never created.
 */
public class PopupBlockerChromeClient extends WebChromeClient {

    public interface Callback {
        void onPopupBlocked(String url);
        /** A window.open()/redirect that would leave the site without the user asking for it. */
        void onRedirectBlocked(String url);
        void onProgressChanged(int newProgress);
        void onShowFileChooser(ValueCallback<android.net.Uri[]> filePathCallback);
        boolean isAdUrl(String url);
    }

    private final Context context;
    private final Callback callback;
    private final PopupGuard guard;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean popupBlockingEnabled = true;
    private long lastOpen;

    public PopupBlockerChromeClient(Context context, PopupGuard guard, Callback callback) {
        this.context = context;
        this.guard = guard;
        this.callback = callback;
    }

    public boolean togglePopupBlocking() {
        popupBlockingEnabled = !popupBlockingEnabled;
        return popupBlockingEnabled;
    }

    public void setPopupBlockingEnabled(boolean on) {
        popupBlockingEnabled = on;
    }

    public boolean isPopupBlockingEnabled() {
        return popupBlockingEnabled;
    }

    @Override
    public boolean onCreateWindow(final WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
        if (popupBlockingEnabled) {
            long now = System.currentTimeMillis();
            boolean tooFast = now - lastOpen < 1500;
            if (!isUserGesture || isDialog || tooFast) {
                if (callback != null) callback.onPopupBlocked("window");
                return false; // refuse: no second window is ever created
            }
            lastOpen = now;
        }
        return routeToSameTab(view, resultMsg);
    }

    /** Hands the new-window request to a hidden WebView just to learn its URL, then loads that URL here. */
    private boolean routeToSameTab(final WebView parent, Message resultMsg) {
        if (resultMsg == null || !(resultMsg.obj instanceof WebView.WebViewTransport)) return false;
        final WebView temp = new WebView(context);
        temp.setWebViewClient(new WebViewClient() {
            private boolean done;

            private void handle(String url) {
                if (done || url == null || url.equals("about:blank")) return;
                done = true;
                if (popupBlockingEnabled && callback != null) {
                    boolean ad = callback.isAdUrl(url);
                    // strict: a new window is only honoured when the user's own tap explains this
                    // exact URL (real <a target=_blank> link). A tap on a button/play control that
                    // opens another site is a hijack - it used to be loaded into the current tab,
                    // which is exactly the "redirect on every tap" behaviour users saw.
                    boolean explained = guard == null || guard.userExplains(parent, url, true);
                    if (ad || !explained) {
                        boolean crossSite = guard == null || !PopupGuard.sameSite(parent.getUrl(), url);
                        if (!ad && crossSite && guard != null && guard.isStrictThirdParty()) {
                            callback.onRedirectBlocked(url);
                        } else {
                            callback.onPopupBlocked(url);
                        }
                        dispose(temp);
                        return;
                    }
                }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    parent.loadUrl(url);
                }
                dispose(temp);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                handle(request.getUrl().toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                handle(url);
            }
        });
        ui.postDelayed(() -> dispose(temp), 4000); // never leak it if no URL ever arrives
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(temp);
        resultMsg.sendToTarget();
        return true;
    }

    private void dispose(final WebView w) {
        ui.post(() -> {
            try {
                w.stopLoading();
                w.destroy();
            } catch (Exception ignored) {
                // already destroyed
            }
        });
    }

    @Override
    public void onCloseWindow(WebView window) {
        // scripts closing windows we never opened: nothing to do
    }

    @Override
    public void onProgressChanged(WebView view, int newProgress) {
        super.onProgressChanged(view, newProgress);
        if (callback != null) callback.onProgressChanged(newProgress);
    }

    @Override
    public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        return super.onJsAlert(view, url, message, result);
    }

    @Override
    public boolean onShowFileChooser(WebView webView, ValueCallback<android.net.Uri[]> filePathCallback,
                                     FileChooserParams fileChooserParams) {
        if (callback != null) {
            callback.onShowFileChooser(filePathCallback);
            return true;
        }
        return false;
    }
}
