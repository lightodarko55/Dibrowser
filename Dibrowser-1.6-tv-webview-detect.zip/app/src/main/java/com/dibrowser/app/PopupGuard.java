package com.dibrowser.app;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.Collections;
import java.util.Locale;

/**
 * Popup / pop-under / forced-redirect guard, modelled on AdGuard Popup Blocker
 * (https://github.com/AdguardTeam/PopupBlocker): instead of a filter list it asks
 * "did a real user action cause this?" for every window.open(), synthetic link click,
 * form target=_blank, meta refresh and invisible click-hijack overlay.
 *
 * Two layers:
 *  1. JS layer (SCRIPT) injected at document start into every frame.
 *  2. Native layer: {@link #shouldBlockNavigation} vetoes top-frame navigations that no
 *     user gesture caused and that jump to a different site (location.href = ad).
 *
 * This is an original implementation of the same idea (the upstream userscript is LGPL-3.0
 * and is not bundled).
 */
public class PopupGuard {

    public interface Listener {
        void onBlocked(String what);
    }

    public static final String JS_NAME = "DibPopup";

    private static final String SCRIPT =
            "(function () {\n" +
            "  if (window.__dibPG) return;\n" +
            "  try { Object.defineProperty(window, '__dibPG', { value: 1 }); } catch (e) { window.__dibPG = 1; }\n" +
            "  var GEST_MS = 800;\n" +
            "  var AUTH = /(^|\\.)(accounts\\.google\\.com|facebook\\.com|appleid\\.apple\\.com|login\\.microsoftonline\\.com|login\\.live\\.com|github\\.com|paypal\\.com|discord\\.com|twitter\\.com|x\\.com|stripe\\.com)$/;\n" +
            "  var lastGesture = 0, lastTarget = null, used = false;\n" +
            "  function off() { return window.__dibPGOff === true; }\n" +
            "  function report(w) { try { if (window.DibPopup) window.DibPopup.blocked(String(w || '')); } catch (e) {} }\n" +
            "  function resolve(u) { try { return new URL(String(u), location.href); } catch (e) { return null; } }\n" +
            "  function tapInfo(t) {\n" +
            "    try {\n" +
            "      var a = t && t.closest ? t.closest('a[href]') : null;\n" +
            "      if (a && !isOverlay(a)) {\n" +
            "        var h = a.getAttribute('href') || '';\n" +
            "        if (/^(#|javascript:)/i.test(h)) return [2, ''];\n" +
            "        var r = resolve(h);\n" +
            "        return [1, r ? r.href : ''];\n" +
            "      }\n" +
            "      if (t && t.closest && t.closest('button,input,select,textarea,label,summary,[role=button],[role=link],[role=tab]')) return [2, ''];\n" +
            "    } catch (e) {}\n" +
            "    return [0, ''];\n" +
            "  }\n" +
            "  function mark(e) {\n" +
            "    if (!e.isTrusted) return;\n" +
            "    lastGesture = Date.now(); lastTarget = e.target; used = false;\n" +
            "    try { var i = tapInfo(e.target); if (window.DibPopup) window.DibPopup.tap(i[0], i[1]); } catch (x) {}\n" +
            "  }\n" +
            "  ['pointerdown', 'mousedown', 'touchstart', 'touchend', 'mouseup', 'click', 'keydown'].forEach(function (t) {\n" +
            "    window.addEventListener(t, mark, true);\n" +
            "  });\n" +
            "  /* big, empty, see-through layer that exists only to hijack the first tap */\n" +
            "  function isOverlay(el) {\n" +
            "    try {\n" +
            "      if (!el || el.nodeType !== 1 || el === document.body || el === document.documentElement) return false;\n" +
            "      var cs = getComputedStyle(el);\n" +
            "      if (cs.position !== 'fixed' && cs.position !== 'absolute') return false;\n" +
            "      var r = el.getBoundingClientRect();\n" +
            "      if (r.width * r.height < innerWidth * innerHeight * 0.5) return false;\n" +
            "      var clear = parseFloat(cs.opacity) < 0.1 || cs.backgroundColor === 'rgba(0, 0, 0, 0)' || cs.backgroundColor === 'transparent';\n" +
            "      if (!clear) return false;\n" +
            "      if ((el.innerText || '').trim().length > 0) return false;\n" +
            "      if (el.querySelector && el.querySelector('video,audio,canvas,iframe,img,input,button,svg')) return false;\n" +
            "      return true;\n" +
            "    } catch (e) { return false; }\n" +
            "  }\n" +
            "  function gestureOK() { return (Date.now() - lastGesture) < GEST_MS && !used && !isOverlay(lastTarget); }\n" +
            "  function newWin(a) {\n" +
            "    var t = String(a.target || '').toLowerCase();\n" +
            "    return t !== '' && t !== '_self' && t !== '_top' && t !== '_parent';\n" +
            "  }\n" +
            "  function crossOrigin(h) { var r = resolve(h); return !!r && r.origin !== location.origin; }\n" +
            "  /* window.open: only when a real tap on the very link being opened (or a same-site / sign-in popup) */\n" +
            "  function allowedOpen(url) {\n" +
            "    if (!gestureOK()) return false;\n" +
            "    var r = resolve(url || location.href);\n" +
            "    if (!r || !/^https?:$/.test(r.protocol)) return false;\n" +
            "    var a = lastTarget && lastTarget.closest ? lastTarget.closest('a[href]') : null;\n" +
            "    if (a) {\n" +
            "      var h = resolve(a.getAttribute('href'));\n" +
            "      if (h && h.origin === r.origin && h.pathname === r.pathname) return true;\n" +
            "    }\n" +
            "    if (r.origin === location.origin) return true;\n" +
            "    return AUTH.test(r.hostname);\n" +
            "  }\n" +
            "  function fake() {\n" +
            "    var f = function () {};\n" +
            "    return { closed: true, focus: f, blur: f, close: f, postMessage: f,\n" +
            "      document: { write: f, writeln: f, open: f, close: f },\n" +
            "      location: { href: '', assign: f, replace: f, reload: f } };\n" +
            "  }\n" +
            "  var realOpen = window.open;\n" +
            "  var guardedOpen = function (url) {\n" +
            "    if (off()) return realOpen.apply(window, arguments);\n" +
            "    if (allowedOpen(url)) { used = true; return realOpen.apply(window, arguments); }\n" +
            "    report('window.open');\n" +
            "    return fake();\n" +
            "  };\n" +
            "  try { Object.defineProperty(window, 'open', { value: guardedOpen, writable: false, configurable: false }); }\n" +
            "  catch (e) { window.open = guardedOpen; }\n" +
            "  /* scripted <a>.click() / dispatchEvent(new MouseEvent('click')) */\n" +
            "  var aClick = HTMLAnchorElement.prototype.click;\n" +
            "  HTMLAnchorElement.prototype.click = function () {\n" +
            "    if (!off() && !gestureOK() && (newWin(this) || crossOrigin(this.href))) { report('link.click'); return; }\n" +
            "    return aClick.apply(this, arguments);\n" +
            "  };\n" +
            "  var dispatch = EventTarget.prototype.dispatchEvent;\n" +
            "  EventTarget.prototype.dispatchEvent = function (ev) {\n" +
            "    try {\n" +
            "      if (!off() && ev && ev.type === 'click' && !ev.isTrusted && this instanceof HTMLAnchorElement &&\n" +
            "          !gestureOK() && (newWin(this) || crossOrigin(this.href))) { report('dispatch'); return false; }\n" +
            "    } catch (e) {}\n" +
            "    return dispatch.apply(this, arguments);\n" +
            "  };\n" +
            "  /* capture-phase click filter (runs before the page's own handlers) */\n" +
            "  window.addEventListener('click', function (e) {\n" +
            "    if (off()) return;\n" +
            "    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;\n" +
            "    if (!e.isTrusted) {\n" +
            "      if (a && newWin(a)) { e.preventDefault(); e.stopImmediatePropagation(); report('synthetic'); }\n" +
            "      return;\n" +
            "    }\n" +
            "    for (var n = e.target, i = 0; n && i < 4; n = n.parentElement, i++) {\n" +
            "      if (isOverlay(n)) {\n" +
            "        e.preventDefault(); e.stopImmediatePropagation();\n" +
            "        n.style.setProperty('pointer-events', 'none', 'important');\n" +
            "        n.style.setProperty('display', 'none', 'important');\n" +
            "        report('overlay');\n" +
            "        return;\n" +
            "      }\n" +
            "    }\n" +
            "  }, true);\n" +
            "  /* <form target=_blank> pop-unders */\n" +
            "  window.addEventListener('submit', function (e) {\n" +
            "    if (!off() && e.target && newWin(e.target) && !gestureOK()) { e.preventDefault(); e.stopImmediatePropagation(); report('form'); }\n" +
            "  }, true);\n" +
            "  var fSubmit = HTMLFormElement.prototype.submit;\n" +
            "  HTMLFormElement.prototype.submit = function () {\n" +
            "    if (!off() && newWin(this) && !gestureOK()) { report('form'); return; }\n" +
            "    return fSubmit.apply(this, arguments);\n" +
            "  };\n" +
            "  /* <meta http-equiv=refresh> to another site */\n" +
            "  function checkMeta(m) {\n" +
            "    try {\n" +
            "      if (m.httpEquiv && m.httpEquiv.toLowerCase() === 'refresh') {\n" +
            "        var mm = /url\\s*=\\s*['\"]?([^'\";]+)/i.exec(m.content || '');\n" +
            "        var r = mm && resolve(mm[1]);\n" +
            "        if (r && r.origin !== location.origin) { m.remove(); report('meta-refresh'); }\n" +
            "      }\n" +
            "    } catch (e) {}\n" +
            "  }\n" +
            "  try {\n" +
            "    new MutationObserver(function (list) {\n" +
            "      if (off()) return;\n" +
            "      list.forEach(function (rec) {\n" +
            "        rec.addedNodes.forEach(function (n) {\n" +
            "          if (n.nodeType !== 1) return;\n" +
            "          if (n.tagName === 'META') checkMeta(n);\n" +
            "          else if (n.querySelectorAll) n.querySelectorAll('meta[http-equiv]').forEach(checkMeta);\n" +
            "        });\n" +
            "      });\n" +
            "    }).observe(document, { childList: true, subtree: true });\n" +
            "  } catch (e) {}\n" +
            "  /* meta refresh that ships in the page's own HTML (the observer only sees added nodes) */\n" +
            "  function scanMetas() {\n" +
            "    try {\n" +
            "      if (off() || !document.querySelectorAll) return;\n" +
            "      document.querySelectorAll('meta[http-equiv]').forEach(checkMeta);\n" +
            "    } catch (e) {}\n" +
            "  }\n" +
            "  scanMetas();\n" +
            "  document.addEventListener('DOMContentLoaded', scanMetas);\n" +
            "})();\n";

    public interface AdCheck {
        boolean isAd(String url);
    }

    private AdCheck adCheck;
    private volatile int tapKind;      // 0 = plain page area, 1 = real link, 2 = button / JS-driven control
    private volatile String tapHref = "";
    private volatile long tapTime;
    private volatile boolean tapConsumed;

    /** "Block third-party redirects" switch: buttons no longer explain a jump to another site. */
    private volatile boolean strictThirdParty;
    /** JS window/overlay guards follow "Block popups"; the native layer follows either switch. */
    private volatile boolean jsEnabled = true;
    /** Consecutive server-side redirect hops that each leave the current site. */
    private int redirectHops;

    /** Trusted sign-in / payment hosts a button is always allowed to open (mirrors AUTH in the script). */
    private static final String[] AUTH_HOSTS = {
            "accounts.google.com", "facebook.com", "appleid.apple.com", "login.microsoftonline.com",
            "login.live.com", "github.com", "paypal.com", "discord.com", "twitter.com", "x.com",
            "stripe.com"
    };

    public void setAdCheck(AdCheck c) {
        adCheck = c;
    }

    @JavascriptInterface
    public void tap(int kind, String href) {
        tapKind = kind;
        tapHref = href == null ? "" : href;
        tapTime = System.currentTimeMillis();
        tapConsumed = false;
    }

    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ScriptHandler scriptHandler;
    private WebView webView;
    private boolean enabled = true;
    private boolean docStart;
    private long lastNotify;

    public PopupGuard(Listener listener) {
        this.listener = listener;
    }

    public void install(WebView wv) {
        webView = wv;
        wv.addJavascriptInterface(this, JS_NAME);
        docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        apply();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isStrictThirdParty() {
        return strictThirdParty;
    }

    /** Single-switch legacy control (both layers together). */
    public void setEnabled(boolean on) {
        enabled = on;
        jsEnabled = on;
        apply();
        if (webView != null) {
            webView.evaluateJavascript("window.__dibPGOff=" + (!jsEnabled) + ";", null);
        }
    }

    /** Two-switch control: "Block popups" drives the JS layer, "Block third-party redirects"
     *  drives the strict native rules; either one keeps the guard itself alive. */
    public void configure(boolean popupsOn, boolean redirectsOn) {
        enabled = popupsOn || redirectsOn;
        strictThirdParty = redirectsOn;
        jsEnabled = popupsOn;
        redirectHops = 0;
        apply();
        if (webView != null) {
            webView.evaluateJavascript("window.__dibPGOff=" + (!jsEnabled) + ";", null);
        }
    }

    private void apply() {
        if (webView == null || !docStart) return;
        if (enabled && scriptHandler == null) {
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(webView, SCRIPT, Collections.singleton("*"));
        } else if (!enabled && scriptHandler != null) {
            scriptHandler.remove();
            scriptHandler = null;
        }
    }

    /** Fallback for WebViews without document-start scripts: inject as early as onPageStarted. */
    public void onPageStarted(WebView view) {
        redirectHops = 0; // a committed page starts a fresh navigation, not a chain continuation
        if (enabled && !docStart) view.evaluateJavascript(SCRIPT, null);
    }

    @JavascriptInterface
    public void blocked(final String what) {
        ui.post(() -> {
            long now = System.currentTimeMillis();
            if (now - lastNotify < 1500) return;
            lastNotify = now;
            if (listener != null) listener.onBlocked(what);
        });
    }

    /**
     * Native redirect guard. Called from shouldOverrideUrlLoading. A top-frame navigation that
     * has no user gesture and is not a server redirect is a script/meta redirect; if it also
     * leaves the current site (or opens an app scheme) it is blocked.
     *
     * Strict ("Block third-party redirects") additions:
     *  - a KNOWN ad/tracker host is always refused, even mid-redirect-chain;
     *  - a chain of more than two server-side redirects that each leave the current site is a
     *    redirector chain (the tap play -&gt; redirector -&gt; tracker -&gt; spam pattern) and is cut off;
     *  - a tap on a button/control no longer explains a jump to a different site (see
     *    {@link #userExplains}).
     */
    public boolean shouldBlockNavigation(WebView view, WebResourceRequest req) {
        if (!enabled || !req.isForMainFrame()) return false;
        String current = view.getUrl();
        if (current == null || current.startsWith("about:") || current.startsWith("data:")) return false;
        String target = req.getUrl().toString();
        String scheme = req.getUrl().getScheme();
        scheme = scheme == null ? "" : scheme.toLowerCase(Locale.ROOT);
        boolean http = scheme.equals("http") || scheme.equals("https");
        if (http && sameSite(current, target)) {
            redirectHops = 0;                     // staying on the site is always fine
            return false;
        }
        if (adCheck != null && adCheck.isAd(target)) {
            redirectHops = 0;                      // known ad/tracker host: refuse, even in a chain
            return true;
        }
        if (Compat.isRedirect(req)) {
            if (strictThirdParty) {
                redirectHops++;
                if (redirectHops > 2) return true; // redirector chain = hijack, cut it off
            }
            return false;                          // short chain: link shorteners etc.
        }
        redirectHops = 0;

        // Leaving the site: only if the user's tap explains it.
        if (userExplains(view, target, Compat.hasGesture(req))) return false;
        return true; // tap on empty page area, no tap at all, or a link pointing somewhere else = hijack
    }

    /**
     * Would a navigation / new window to {@code target} be explained by what the user just did?
     * Independent of the injected JS: also consults the WebView's own hit test (the link under the
     * last touch), so it keeps working on WebViews where document-start scripts are unavailable.
     *
     * Strict mode: a tap on a BUTTON only ever explains the site the user is already on, or a
     * trusted sign-in/payment host. The old behaviour (any button tap explained any URL) is what
     * let "tap Play/Download - get redirected to an ad site" through.
     */
    public boolean userExplains(WebView view, String target, boolean viaGesture) {
        if (System.currentTimeMillis() - tapTime < 1500 && !tapConsumed) {
            if (tapKind == 1 && sameSite(tapHref, target)) {
                tapConsumed = true;
                return true;
            }
            if (tapKind == 2) {
                if (!strictThirdParty) {
                    tapConsumed = true;
                    return true;
                }
                String current = view != null ? view.getUrl() : null;
                if (isAuthHost(target) || sameSite(current, target)) {
                    tapConsumed = true;
                    return true;
                }
            }
        }
        if (viaGesture) {
            try {
                WebView.HitTestResult hit = view.getHitTestResult();
                if (hit != null && hit.getExtra() != null
                        && (hit.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE
                        || hit.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                        && sameSite(hit.getExtra(), target)) {
                    return true;
                }
            } catch (Exception ignored) { }
        }
        return false;
    }

    /** host of {@code url} is a trusted sign-in / payment host (or a subdomain of one) */
    public static boolean isAuthHost(String url) {
        String h = host(url);
        if (h == null) return false;
        h = h.toLowerCase(Locale.ROOT);
        for (String a : AUTH_HOSTS) {
            if (h.equals(a) || h.endsWith("." + a)) return true;
        }
        return false;
    }

    public static boolean sameSite(String a, String b) {
        String ha = base(host(a));
        String hb = base(host(b));
        return ha != null && ha.equals(hb);
    }

    private static String host(String url) {
        try {
            return android.net.Uri.parse(url).getHost();
        } catch (Exception e) {
            return null;
        }
    }

    /** Crude registrable domain: last two labels (three for co.uk-style endings). */
    private static String base(String host) {
        if (host == null) return null;
        String[] p = host.toLowerCase(Locale.ROOT).split("\\.");
        int n = p.length;
        if (n <= 2) return host;
        if (p[n - 1].length() == 2 && p[n - 2].length() <= 3) return p[n - 3] + "." + p[n - 2] + "." + p[n - 1];
        return p[n - 2] + "." + p[n - 1];
    }
}
