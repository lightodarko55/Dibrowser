package com.dibrowser.app;

import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;

/**
 * Incognito/privacy mode: while enabled, cookies aren't persisted and every entry added
 * to the in-memory history list is wiped the moment the mode is turned off (or the app
 * closes). This mirrors "Privacy Mode Protection" — no traces left after the session.
 *
 * It does not spin up a second WebView; it toggles the SAME WebView's cookie persistence
 * and clears its cache/form data/history on enable and on disable, which is simpler and
 * avoids the state-sync bugs that come from juggling two WebView instances.
 */
public class PrivacyModeManager {

    private boolean active = false;
    private final java.util.List<String> sessionHistory = new java.util.ArrayList<>();

    public boolean isActive() {
        return active;
    }

    /** Call when the user toggles privacy mode on. */
    public void enable(WebView webView) {
        active = true;
        CookieManager.getInstance().setAcceptCookie(false);
        clearTraces(webView);
        sessionHistory.clear();
    }

    /** Call when the user toggles privacy mode off, or when leaving the app while it was active. */
    public void disable(WebView webView) {
        active = false;
        CookieManager.getInstance().setAcceptCookie(true);
        clearTraces(webView);
        sessionHistory.clear();
    }

    private void clearTraces(WebView webView) {
        webView.clearHistory();
        webView.clearCache(true);
        webView.clearFormData();
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
    }

    /** Record a visited URL for the in-session "incognito history" list shown in the UI. */
    public void recordVisit(String url) {
        if (!active || url == null) return;
        sessionHistory.add(0, url); // newest first
    }

    public java.util.List<String> getSessionHistory() {
        return sessionHistory;
    }

    public void removeFromHistory(int index) {
        if (index >= 0 && index < sessionHistory.size()) {
            sessionHistory.remove(index);
        }
    }
}
