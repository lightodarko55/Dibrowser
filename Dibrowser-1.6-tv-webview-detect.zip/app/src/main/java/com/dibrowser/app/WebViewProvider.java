package com.dibrowser.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;

import androidx.webkit.WebViewCompat;

/**
 * Detects which app on the device is actually rendering the WebView (Android's "WebView
 * implementation" is a single, swappable system component - it is never bundled with this app).
 *
 * On most phones that is "Android System WebView" or, on many Samsung/Xiaomi/TV boxes, the
 * Chrome app itself acting as the provider. Some cheap/old Android TV boxes ship with a very
 * old or even disabled WebView component, which is the actual cause of "TV lags/crashes on
 * websites, mobile works fine" - the WebView engine on that box is years behind Chrome.
 *
 * IMPORTANT: no Android app can choose or force a WebView implementation from code - there is no
 * API for it. The provider (Android System WebView, or Chrome itself on devices where Chrome is
 * set as the provider) is picked by the OS, and can only be changed by a human in Android's own
 * Developer options screen ("WebView implementation", Android 7-9 only - most Android 10+ builds
 * removed the picker because the OS now auto-selects whichever eligible, enabled provider has the
 * newest version code). "Android System WebView" showing up here is not itself a problem: on
 * modern Android it's built from the same Blink/V8 engine as Chrome (Project Trichrome) and is
 * auto-updated by Google through the Play Store the same way Chrome is - only its *version* matters.
 *
 * What this class actually does:
 *  - identifies the active provider's package + version at startup,
 *  - decides whether that version is modern enough to be trusted with heavy JS,
 *  - automatically drops into the lighter/compatible profile (same "lite" switches already used
 *    for low-RAM TVs) when it is not,
 *  - offers a one-tap path to update the provider from the Play Store, and
 *  - offers a shortcut into Android's own Developer options screen, where a human can see/pick
 *    the provider on the (older) devices that still expose that choice.
 */
final class WebViewProvider {

    /** Known WebView-provider package names, newest/most-capable first. */
    private static final String PKG_CHROME = "com.android.chrome";
    private static final String PKG_CHROME_BETA = "com.chrome.beta";
    private static final String PKG_CHROME_DEV = "com.chrome.dev";
    private static final String PKG_CHROME_CANARY = "com.chrome.canary";
    private static final String PKG_SYSTEM_WEBVIEW = "com.google.android.webview";
    private static final String PKG_SYSTEM_WEBVIEW_BETA = "com.google.android.webview.beta";

    /** Below this major version a WebView is treated as "too old" (modern JS/CSS features missing). */
    private static final int MIN_HEALTHY_MAJOR_VERSION = 90;

    static final class Info {
        final String packageName;   // null if the provider could not be determined at all
        final String versionName;   // e.g. "128.0.6613.40", may be null
        final int majorVersion;     // parsed leading number, -1 if unknown
        final boolean isChromeApp;  // provider is the actual Chrome app (vs. the slim WebView-only package)
        final boolean healthy;      // modern enough to run full (non-lite) settings safely

        Info(String packageName, String versionName, int majorVersion, boolean isChromeApp, boolean healthy) {
            this.packageName = packageName;
            this.versionName = versionName;
            this.majorVersion = majorVersion;
            this.isChromeApp = isChromeApp;
            this.healthy = healthy;
        }
    }

    private WebViewProvider() { }

    /** Reads the current WebView-implementation package straight from the framework/AndroidX shim. */
    static Info detect(Context ctx) {
        try {
            PackageInfo pi = WebViewCompat.getCurrentWebViewPackage(ctx);
            if (pi == null) {
                // Pre-Lollipop-MR1 fallback path - shouldn't happen above minSdk 21 in practice,
                // but never crash the browser over a diagnostic.
                return new Info(null, null, -1, false, true);
            }
            String pkg = pi.packageName;
            String version = pi.versionName;
            int major = parseMajor(version);
            boolean isChrome = PKG_CHROME.equals(pkg) || PKG_CHROME_BETA.equals(pkg)
                    || PKG_CHROME_DEV.equals(pkg) || PKG_CHROME_CANARY.equals(pkg);
            boolean healthy = major < 0 || major >= MIN_HEALTHY_MAJOR_VERSION;
            Log.i("WebViewProvider", "engine=" + pkg + " version=" + version + " healthy=" + healthy);
            return new Info(pkg, version, major, isChrome, healthy);
        } catch (Throwable t) {
            // getCurrentWebViewPackage can throw on some OEM TV firmwares with a broken package
            // manager stub - treat as unknown/healthy rather than blocking startup.
            Log.w("WebViewProvider", "detect failed", t);
            return new Info(null, null, -1, false, true);
        }
    }

    private static int parseMajor(String versionName) {
        if (versionName == null || versionName.isEmpty()) return -1;
        int dot = versionName.indexOf('.');
        String head = dot >= 0 ? versionName.substring(0, dot) : versionName;
        try {
            return Integer.parseInt(head.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Play Store / Play Store web listing for whichever provider is currently in use (or Chrome, if unknown). */
    static Intent updateIntent(Info info) {
        String pkg = (info.packageName != null) ? info.packageName : PKG_CHROME;
        Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
        return market;
    }

    static Intent updateIntentWebFallback(Info info) {
        String pkg = (info.packageName != null) ? info.packageName : PKG_CHROME;
        return new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
    }

    /**
     * Opens Android's own Developer options screen. This is the one and only place in the OS
     * where the WebView-rendering component can be switched by a human ("Developer options >
     * WebView implementation", Android 7-9; on Android 10+ most manufacturers removed that picker
     * entirely because the OS now auto-selects whichever eligible provider has the newest version
     * code, so the app can land on this screen but can't drive the switch itself from here - no
     * app, including this one, can set the WebView provider in code; there's no API for it).
     */
    static Intent developerOptionsIntent() {
        return new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
    }

    static String label(Info info) {
        if (info.packageName == null) return "Unknown";
        if (PKG_SYSTEM_WEBVIEW.equals(info.packageName) || PKG_SYSTEM_WEBVIEW_BETA.equals(info.packageName)) {
            return "Android System WebView" + (info.versionName != null ? " " + info.versionName : "");
        }
        if (info.isChromeApp) {
            return "Chrome" + (info.versionName != null ? " " + info.versionName : "");
        }
        return info.packageName + (info.versionName != null ? " " + info.versionName : "");
    }
}
