package com.dibrowser.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/**
 * On-screen mouse pointer for D-pad / TV-remote control. It is purely visual; MainActivity moves
 * it with the arrow keys and turns DPAD_CENTER into a tap at the pointer position.
 *
 * TV tuning:
 *  - auto-hide: the pointer disappears after {@link Prefs#CURSOR_HIDE_MS} without a key press and
 *    comes back on the next one (one cheap invalidate, no animation, no extra layers);
 *  - the arrow path is built once and only translated while drawing (no allocation per frame);
 *  - only the small rectangle around the pointer is redrawn.
 */
public class CursorView extends View {

    // Arrow outline in dp, origin = pointer tip.
    private static final float[] ARROW = {
            0f, 0f, 0f, 20f, 5f, 15.5f, 9f, 23f, 12f, 21.5f, 8f, 14.5f, 14f, 14.5f
    };
    private static final float ARROW_W = 14f, ARROW_H = 23f;

    private float x = -1, y = -1;
    private boolean shown = true;
    private boolean autoHide = true;
    private float sizeScale = 1.4f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();
    private final float density;

    private final Runnable hideTask = new Runnable() {
        @Override
        public void run() {
            if (shown) {
                shown = false;
                invalidatePointer();
            }
        }
    };

    public CursorView(Context c) { this(c, null); }

    public CursorView(Context c, AttributeSet a) {
        super(c, a);
        density = getResources().getDisplayMetrics().density;
        setFocusable(false);
        setClickable(false);
        fill.setColor(0xFFFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFF000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        rebuildArrow();
    }

    private void rebuildArrow() {
        float s = density * sizeScale;
        arrow.reset();
        arrow.moveTo(ARROW[0] * s, ARROW[1] * s);
        for (int i = 2; i < ARROW.length; i += 2) arrow.lineTo(ARROW[i] * s, ARROW[i + 1] * s);
        arrow.close();
        stroke.setStrokeWidth(Math.max(2f, 1.5f * density * Math.min(sizeScale, 1.6f)));
    }

    // ---- settings ---------------------------------------------------------------------------
    public void setSizeScale(float scale) {
        if (scale == sizeScale) return;
        invalidatePointer();
        sizeScale = scale;
        rebuildArrow();
        invalidatePointer();
    }

    public void setAutoHide(boolean on) {
        autoHide = on;
        removeCallbacks(hideTask);
        if (on) {
            if (shown) postDelayed(hideTask, Prefs.CURSOR_HIDE_MS);
        } else if (!shown) {
            shown = true;
            invalidatePointer();
        }
    }

    /** Turns the whole overlay on (browser page + cursor enabled) or off. */
    public void setActive(boolean active) {
        removeCallbacks(hideTask);
        if (active) {
            setVisibility(VISIBLE);
            wake();
        } else {
            setVisibility(GONE);
        }
    }

    // ---- visibility / auto-hide -------------------------------------------------------------
    /** True while the pointer is on screen. */
    public boolean isPointerShown() { return shown; }

    /** Shows the pointer if it was hidden and restarts the idle timer. */
    public void wake() {
        removeCallbacks(hideTask);
        if (!shown) {
            shown = true;
            invalidatePointer();
        }
        if (autoHide) postDelayed(hideTask, Prefs.CURSOR_HIDE_MS);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(hideTask);
        super.onDetachedFromWindow();
    }

    // ---- position ---------------------------------------------------------------------------
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (x < 0 || y < 0) {
            x = w / 2f;
            y = h / 2f;
        }
        x = Math.min(x, w);
        y = Math.min(y, h);
    }

    public float pointerX() { return x; }
    public float pointerY() { return y; }

    /** Moves the pointer, clamped to the view. Returns true if it actually moved. */
    public boolean moveBy(float dx, float dy) {
        float nx = Math.max(0, Math.min(getWidth() - 1, x + dx));
        float ny = Math.max(0, Math.min(getHeight() - 1, y + dy));
        boolean moved = nx != x || ny != y;
        if (moved) {
            if (shown) invalidatePointer();   // old spot
            x = nx;
            y = ny;
            if (shown) invalidatePointer();   // new spot
        }
        return moved;
    }

    /** Redraw only the small area around the pointer (cheap on TV GPUs). */
    private void invalidatePointer() {
        if (x < 0) return;
        float s = density * sizeScale;
        int pad = (int) (ARROW_W * s) + 8;
        int padY = (int) (ARROW_H * s) + 8;
        invalidate((int) x - 4, (int) y - 4, (int) x + pad, (int) y + padY);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (x < 0 || !shown) return;
        int save = c.save();
        c.translate(x, y);
        c.drawPath(arrow, fill);
        c.drawPath(arrow, stroke);
        c.restoreToCount(save);
    }
}
