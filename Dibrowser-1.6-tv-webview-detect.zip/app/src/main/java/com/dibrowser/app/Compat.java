package com.dibrowser.app;

import android.os.Build;
import android.webkit.WebResourceRequest;

/**
 * WebResourceRequest.hasGesture() / isRedirect() only exist on API 24+. The app supports API 21+,
 * and calling them on an older TV box throws NoSuchMethodError (instant crash while browsing).
 */
final class Compat {
    private Compat() { }

    /** Unknown on API &lt; 24 -> false (the conservative answer for the popup / redirect guard). */
    static boolean hasGesture(WebResourceRequest r) {
        return Build.VERSION.SDK_INT >= 24 && r.hasGesture();
    }

    /** Unknown on API &lt; 24 -> true, so ordinary link redirects keep working on old systems. */
    static boolean isRedirect(WebResourceRequest r) {
        return Build.VERSION.SDK_INT < 24 || r.isRedirect();
    }
}
