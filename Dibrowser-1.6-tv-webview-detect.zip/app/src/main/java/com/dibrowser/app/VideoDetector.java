package com.dibrowser.app;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Improves on basic "scan the HTML for <video src>" detection, which is where many
 * HiBrowser-style video finders fall short. It combines three layers:
 *
 *  1. DOM scan (JS injected into the page): walks <video>, <source>, and common
 *     player containers, including inside same-origin <iframe>s.
 *  2. MutationObserver (same injected script): catches players that attach their
 *     <video>/<source> elements asynchronously after page load (most modern sites).
 *  3. Network-level sniffing (onResourceRequested, called from shouldInterceptRequest
 *     in MainActivity): catches direct media requests (.mp4/.m3u8/.mpd/.ts, and
 *     Range-requested blobs) that never appear as a DOM element at all, which is the
 *     most common reason "video not found" happens on sites using MSE/HLS.js/dash.js
 *     players that fetch segments via JS instead of a plain <video src>.
 *
 * Results are de-duplicated by MainActivity.
 */
public class VideoDetector {

    public static final String JS_INTERFACE_NAME = "AndroidVideoDetector";

    public interface Listener {
        void onVideoFound(VideoResult result);
    }

    public static class VideoResult {
        public final String url;
        public final String type; // "mp4", "hls", "dash", "dom", "blob"
        public final String pageUrl;
        /** Headers the page itself sent for this request (Referer/Origin/User-Agent); may be null. */
        public final java.util.Map<String, String> headers;

        public VideoResult(String url, String type, String pageUrl) {
            this(url, type, pageUrl, null);
        }

        public VideoResult(String url, String type, String pageUrl, java.util.Map<String, String> headers) {
            this.url = url;
            this.type = type;
            this.pageUrl = pageUrl;
            this.headers = headers;
        }
    }

    private final Context context;
    private final Listener listener;
    private final JsBridge jsBridge;

    // Patterns for the network-sniffing layer.
    private static final Pattern DIRECT_MEDIA = Pattern.compile(
            "\\.(mp4|m3u8|mpd|webm|mkv|m4v|mov|flv|avi|3gp|ogv|wmv|mpg|mpeg|m2ts|mts)(?![A-Za-z0-9])|\\.isml?/manifest", Pattern.CASE_INSENSITIVE);

    public VideoDetector(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
        this.jsBridge = new JsBridge();
    }

    public Object getJsInterface() {
        return jsBridge;
    }

    /** Called by MainActivity's WebViewClient.shouldInterceptRequest for every network request. */
    public void onResourceRequested(String url, java.util.Map<String, String> requestHeaders) {
        if (url == null || url.startsWith("blob:") || url.startsWith("data:")) return;
        // cheap pre-filter: this runs for every request the page makes (important on weak TV CPUs)
        if (url.indexOf('.') < 0 || !mayBeMedia(url)) return;
        if (DIRECT_MEDIA.matcher(stripHostPart(url)).find() && markSeen(url)) {
            String type = classify(url);
            java.util.Map<String, String> keep = new java.util.HashMap<>();
            if (requestHeaders != null) {
                for (java.util.Map.Entry<String, String> e : requestHeaders.entrySet()) {
                    String k = e.getKey();
                    if (k.equalsIgnoreCase("Referer") || k.equalsIgnoreCase("Origin")
                            || k.equalsIgnoreCase("User-Agent")) {
                        keep.put(k.substring(0, 1).toUpperCase(Locale.US) + k.substring(1).toLowerCase(Locale.US)
                                .replace("user-agent", "User-Agent"), e.getValue());
                    }
                }
            }
            if (listener != null) {
                listener.onVideoFound(new VideoResult(url, type, url, keep));
            }
        }
    }

    // Separate sets: the network sniffer sees the page's REAL request headers, so its report must
    // still get through even when the JS layer already reported the same URL (and may upgrade it).
    private final java.util.Set<String> reportedNative =
            java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
    private final java.util.Set<String> reportedJs =
            java.util.Collections.synchronizedSet(new java.util.HashSet<String>());

    private boolean markSeen(String url) {
        return reportedNative.add(url);
    }

    private boolean markSeenJs(String url) {
        return reportedJs.add(url);
    }

    /** Forget what was reported (new page). */
    public void reset() {
        reportedNative.clear();
        reportedJs.clear();
    }

    private static boolean mayBeMedia(String url) {
        String l = url.toLowerCase(Locale.US);
        return l.contains(".m3u8") || l.contains(".mpd") || l.contains(".mp4") || l.contains(".mkv")
                || l.contains(".webm") || l.contains(".m4v") || l.contains(".mov") || l.contains(".flv")
                || l.contains(".avi") || l.contains(".3gp") || l.contains(".ogv") || l.contains(".wmv")
                || l.contains(".mpg") || l.contains(".mpeg") || l.contains(".m2ts") || l.contains(".mts")
                || l.contains(".ism/manifest") || l.contains(".isml/manifest");
    }

    /** Drops "https://host" so a host like "mp4.example.com" is not mistaken for a file. */
    private static String stripHostPart(String url) {
        int s = url.indexOf("://");
        if (s < 0) return url;
        int slash = url.indexOf('/', s + 3);
        return slash < 0 ? "" : url.substring(slash);
    }

    private androidx.webkit.ScriptHandler scriptHandler;

    /** Injects the sniffer at document start in EVERY frame (iframes included) when the WebView supports it. */
    public void install(WebView webView) {
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT)) {
            scriptHandler = androidx.webkit.WebViewCompat.addDocumentStartJavaScript(
                    webView, SCAN_SCRIPT, java.util.Collections.singleton("*"));
        }
    }

    /** Injects the DOM-scanning + MutationObserver script into the current page. */
    public void scan(WebView webView) {
        webView.evaluateJavascript(SCAN_SCRIPT, null);
    }

    public void release() {
        // Nothing to clean up yet, but kept as an explicit lifecycle hook so adding
        // (e.g.) a background polling Handler later doesn't require touching MainActivity.
    }

    private String classify(String url) {
        String lower = url.toLowerCase(Locale.US);
        if (lower.contains(".m3u8")) return "hls";
        if (lower.contains(".mpd")) return "dash";
        if (lower.contains(".ism/manifest") || lower.contains(".isml/manifest")) return "smooth";
        if (lower.contains(".mp4")) return "mp4";
        if (lower.contains(".3gp")) return "3gp";
        if (lower.contains(".flv")) return "flv";
        if (lower.contains(".mov")) return "mov";
        if (lower.contains(".m4v")) return "m4v";
        if (lower.contains(".ogv")) return "ogv";
        if (lower.contains(".wmv")) return "wmv";
        if (lower.contains(".avi")) return "avi";
        if (lower.contains(".m2ts") || lower.contains(".mts")) return "mts";
        if (lower.contains(".mpg") || lower.contains(".mpeg")) return "mpeg";
        if (lower.contains(".webm")) return "webm";
        if (lower.contains(".mkv")) return "mkv";
        if (lower.contains(".ts")) return "ts-segment";
        return "media";
    }

    /** Exposed to page JS as window.AndroidVideoDetector.reportVideo(url, type) */
    public class JsBridge {
        @JavascriptInterface
        public void reportVideo(String url, String type) {
            reportVideo(url, type, null);
        }

        /** referer = address of the frame that found it (the embed/iframe, not necessarily the main page). */
        @JavascriptInterface
        public void reportVideo(String url, String type, String referer) {
            if (url == null || url.isEmpty() || url.startsWith("blob:") || url.startsWith("data:")) return;
            if (!markSeenJs(url)) return;
            if (!DIRECT_MEDIA.matcher(stripHostPart(url)).find()) {
                if (type == null || type.equals("dom")) type = "media";
            } else {
                type = classify(url);
            }
            java.util.Map<String, String> h = new java.util.HashMap<>();
            if (referer != null && referer.startsWith("http")) {
                h.put("Referer", referer);
                try {
                    android.net.Uri r = android.net.Uri.parse(referer);
                    h.put("Origin", r.getScheme() + "://" + r.getAuthority());
                } catch (Exception ignored) { }
            }
            if (listener != null) {
                listener.onVideoFound(new VideoResult(url, type, referer == null ? url : referer, h));
            }
        }
    }

    private static final String SCAN_SCRIPT = (
            "(function () {\n" +
            "  if (window.__avd2) { try { window.__avdScan && window.__avdScan(); } catch (e) {} return; }\n" +
            "  window.__avd2 = 1;\n" +
            "  var B = window.__IF__;\n" +
            "  var seen = {};\n" +
            "  var EXT = '(?:m3u8|mpd|mp4|mkv|webm|m4v|mov|flv|avi|3gp|ogv|wmv|mpe?g|m2ts|mts)';\n" +
            "  var RX = new RegExp('https?:\\\\/\\\\/[^\\\\s\"\\'<>\\\\\\\\)\\\\]]+?\\\\.' + EXT + '(?![A-Za-z0-9])(?:\\\\?[^\\\\s\"\\'<>\\\\\\\\)\\\\]]*)?', 'ig');\n" +
            "  var RXREL = new RegExp('^[^?#]*\\\\.' + EXT + '(?![A-Za-z0-9])', 'i');\n" +
            "  function abs(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return u; } }\n" +
            "  function report(u, hint) {\n" +
            "    try {\n" +
            "      if (!u || typeof u !== 'string') return;\n" +
            "      u = abs(u.replace(/\\\\\\//g, '/').replace(/\\\\u0026/g, '&').replace(/&amp;/g, '&'));\n" +
            "      if (/^(blob:|data:)/i.test(u) || seen[u]) return;\n" +
            "      seen[u] = 1;\n" +
            "      if (B) B.reportVideo(u, hint || 'dom', location.href);\n" +
            "    } catch (e) {}\n" +
            "  }\n" +
            "  /* extension-less playlists/manifests: recognised by the response Content-Type */\n" +
            "  function mct(ct, u) {\n" +
            "    if (!ct || !u) return;\n" +
            "    if (ct.indexOf('mpegurl') >= 0) report(u, 'hls');\n" +
            "    else if (ct.indexOf('dash+xml') >= 0) report(u, 'dash');\n" +
            "    else if (ct.indexOf('sstr') >= 0) report(u, 'smooth');\n" +
            "  }\n" +
            "  function scanText(t) {\n" +
            "    if (!t || t.length > 3000000) return;\n" +
            "    t = t.replace(/\\\\\\//g, '/').replace(/\\\\u0026/g, '&').replace(/&amp;/g, '&');\n" +
            "    var m;\n" +
            "    RX.lastIndex = 0;\n" +
            "    while ((m = RX.exec(t)) !== null) report(m[0]);\n" +
            "  }\n" +
            "  function scanDoc() {\n" +
            "    try {\n" +
            "      var vs = document.querySelectorAll('video,audio');\n" +
            "      for (var i = 0; i < vs.length; i++) {\n" +
            "        var v = vs[i];\n" +
            "        if (v.currentSrc) report(v.currentSrc);\n" +
            "        if (v.src) report(v.src);\n" +
            "        var ss = v.querySelectorAll('source');\n" +
            "        for (var j = 0; j < ss.length; j++) if (ss[j].src) report(ss[j].src);\n" +
            "      }\n" +
            "      var as = document.querySelectorAll('a[href],source[src],[data-src],[data-file],[data-url],[data-video],[data-stream]');\n" +
            "      for (var k = 0; k < as.length; k++) {\n" +
            "        var el = as[k];\n" +
            "        var c = [el.getAttribute('href'), el.getAttribute('src'), el.getAttribute('data-src'), el.getAttribute('data-file'),\n" +
            "                 el.getAttribute('data-url'), el.getAttribute('data-video'), el.getAttribute('data-stream')];\n" +
            "        for (var q = 0; q < c.length; q++) if (c[q] && RXREL.test(c[q])) report(c[q]);\n" +
            "      }\n" +
            "      var sc = document.getElementsByTagName('script');\n" +
            "      for (var s = 0; s < sc.length; s++) if (!sc[s].src) scanText(sc[s].textContent);\n" +
            "    } catch (e) {}\n" +
            "  }\n" +
            "  window.__avdScan = scanDoc;\n" +
            "  /* media element events (capture: they do not bubble) */\n" +
            "  ['loadstart', 'loadedmetadata', 'play', 'playing'].forEach(function (t) {\n" +
            "    document.addEventListener(t, function (e) {\n" +
            "      var v = e.target;\n" +
            "      if (v && (v.tagName === 'VIDEO' || v.tagName === 'AUDIO')) { report(v.currentSrc); report(v.src); }\n" +
            "    }, true);\n" +
            "  });\n" +
            "  /* network hooks: see every manifest / file / JSON api the player asks for, even before play */\n" +
            "  try {\n" +
            "    var xo = XMLHttpRequest.prototype.open;\n" +
            "    XMLHttpRequest.prototype.open = function (m, u) {\n" +
            "      try {\n" +
            "        var url = String(u);\n" +
            "        if (RXREL.test(url)) report(url);\n" +
            "        this.addEventListener('load', function () {\n" +
            "          try {\n" +
            "            var ct = (this.getResponseHeader('content-type') || '').toLowerCase();\n" +
            "            mct(ct, this.responseURL);\n" +
            "            if ((this.responseType === '' || this.responseType === 'text') && /json|javascript|text\\/plain|mpegurl|dash/.test(ct)) {\n" +
            "              scanText(this.responseText);\n" +
            "            }\n" +
            "          } catch (e) {}\n" +
            "        });\n" +
            "      } catch (e) {}\n" +
            "      return xo.apply(this, arguments);\n" +
            "    };\n" +
            "  } catch (e) {}\n" +
            "  try {\n" +
            "    var of = window.fetch;\n" +
            "    window.fetch = function (input) {\n" +
            "      var url = '';\n" +
            "      try { url = typeof input === 'string' ? input : (input && input.url) || ''; if (RXREL.test(url)) report(url); } catch (e) {}\n" +
            "      var p = of.apply(this, arguments);\n" +
            "      try {\n" +
            "        p.then(function (res) {\n" +
            "          try {\n" +
            "            var ct = (res.headers.get('content-type') || '').toLowerCase();\n" +
            "            mct(ct, res.url || url);\n" +
            "            if (/json|javascript|text\\/plain|mpegurl|dash/.test(ct)) res.clone().text().then(scanText).catch(function () {});\n" +
            "          } catch (e) {}\n" +
            "        }).catch(function () {});\n" +
            "      } catch (e) {}\n" +
            "      return p;\n" +
            "    };\n" +
            "  } catch (e) {}\n" +
            "  try {\n" +
            "    var desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');\n" +
            "    if (desc && desc.set) {\n" +
            "      Object.defineProperty(HTMLMediaElement.prototype, 'src', {\n" +
            "        configurable: true, enumerable: desc.enumerable, get: desc.get,\n" +
            "        set: function (v) { try { report(String(v)); } catch (e) {} return desc.set.call(this, v); }\n" +
            "      });\n" +
            "    }\n" +
            "  } catch (e) {}\n" +
            "  /* periodic + mutation driven rescans (debounced) */\n" +
            "  var timer = null;\n" +
            "  function later() { if (timer) return; timer = setTimeout(function () { timer = null; scanDoc(); }, 700); }\n" +
            "  try {\n" +
            "    new MutationObserver(later).observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'href'] });\n" +
            "  } catch (e) {}\n" +
            "  [500, 1500, 3500, 7000, 12000].forEach(function (ms) { setTimeout(scanDoc, ms); });\n" +
            "  document.addEventListener('DOMContentLoaded', scanDoc);\n" +
            "  window.addEventListener('load', scanDoc);\n" +
            "})();\n"
    ).replace("__IF__", JS_INTERFACE_NAME);
}
