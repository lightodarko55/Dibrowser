package com.dibrowser.app;

import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** RecyclerView adapters for the home tiles and the Bookmark / History / IPTV list rows. */
public final class Adapters {

    private Adapters() {}

    private static final int[] TILE_COLORS = {
            0xFFE53935, 0xFF1E88E5, 0xFF43A047, 0xFFF4511E, 0xFF8E24AA, 0xFF00897B, 0xFFFB8C00, 0xFF3949AB
    };

    public static int colorFor(String name) {
        return TILE_COLORS[(name.hashCode() & 0x7fffffff) % TILE_COLORS.length];
    }

    // ---------------------------------------------------------------- home tiles
    public interface TileListener {
        void onTileClick(Prefs.Entry e);
        void onTileLongClick(Prefs.Entry e);
        void onAddClick();
    }

    public static class TileAdapter extends RecyclerView.Adapter<TileAdapter.VH> {
        private final List<Prefs.Entry> items = new ArrayList<>();
        private final TileListener listener;

        public TileAdapter(TileListener l) { listener = l; }

        public void set(List<Prefs.Entry> list) {
            items.clear();
            items.addAll(list);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_tile, p, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            if (pos == items.size()) { // trailing "+" tile
                h.letter.setText("+");
                h.letter.setBackground(circle(0xFF3A3D45));
                h.label.setText("Add");
                h.itemView.setOnClickListener(v -> listener.onAddClick());
                h.itemView.setOnLongClickListener(null);
                return;
            }
            final Prefs.Entry e = items.get(pos);
            String l = e.title.isEmpty() ? "?" : e.title.substring(0, 1).toUpperCase(Locale.getDefault());
            h.letter.setText(l);
            h.letter.setBackground(circle(colorFor(e.title)));
            h.label.setText(e.title);
            h.itemView.setOnClickListener(v -> listener.onTileClick(e));
            h.itemView.setOnLongClickListener(v -> { listener.onTileLongClick(e); return true; });
        }

        @Override
        public int getItemCount() { return items.size() + 1; }

        private static GradientDrawable circle(int color) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            return g;
        }

        static class VH extends RecyclerView.ViewHolder {
            final TextView letter, label;
            VH(View v) {
                super(v);
                letter = v.findViewById(R.id.tile_letter);
                label = v.findViewById(R.id.tile_label);
            }
        }
    }

    // ---------------------------------------------------------------- list rows
    public static class Row {
        public final String title, subtitle;
        public final int icon;
        public final Runnable click, longClick;

        public Row(String title, String subtitle, int icon, Runnable click, Runnable longClick) {
            this.title = title;
            this.subtitle = subtitle;
            this.icon = icon;
            this.click = click;
            this.longClick = longClick;
        }
    }

    public static class RowAdapter extends RecyclerView.Adapter<RowAdapter.VH> {
        private final List<Row> rows = new ArrayList<>();

        public void set(List<Row> list) {
            rows.clear();
            rows.addAll(list);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_row, p, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            final Row r = rows.get(pos);
            h.title.setText(r.title);
            h.sub.setText(r.subtitle);
            h.icon.setImageResource(r.icon);
            h.itemView.setOnClickListener(v -> { if (r.click != null) r.click.run(); });
            h.itemView.setOnLongClickListener(v -> {
                if (r.longClick == null) return false;
                r.longClick.run();
                return true;
            });
        }

        @Override
        public int getItemCount() { return rows.size(); }

        static class VH extends RecyclerView.ViewHolder {
            final TextView title, sub;
            final ImageView icon;
            VH(View v) {
                super(v);
                title = v.findViewById(R.id.row_title);
                sub = v.findViewById(R.id.row_subtitle);
                icon = v.findViewById(R.id.row_icon);
            }
        }
    }
}
