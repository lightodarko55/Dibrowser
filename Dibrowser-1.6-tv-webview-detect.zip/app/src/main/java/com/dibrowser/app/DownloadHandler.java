package com.dibrowser.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.StatFs;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;

import androidx.appcompat.app.AlertDialog;

import java.util.Locale;

/**
 * File download flow, shown as a confirmation dialog (filename / size / available space,
 * Cancel / Download) before handing the request to Android's DownloadManager, which then
 * shows system download progress and a completion notification.
 *
 * Attach via webView.setDownloadListener(new DownloadHandler(activity)::onDownloadStart).
 */
public class DownloadHandler {

    private final Activity activity;

    public DownloadHandler(Activity activity) {
        this.activity = activity;
    }

    public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                 String mimeType, long contentLength) {
        String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
        String sizeLabel = contentLength > 0 ? formatBytes(contentLength) : "Unknown";
        String availableLabel = formatBytes(getAvailableInternalBytes());

        android.view.View dialogView = android.view.LayoutInflater.from(activity)
                .inflate(android.R.layout.simple_list_item_1, null); // minimal fallback if no custom layout wanted

        new AlertDialog.Builder(activity)
                .setTitle("Download")
                .setMessage("File name: " + fileName
                        + "\nFile size: " + sizeLabel
                        + "\nAvailable space: " + availableLabel
                        + "\n\n" + url)
                .setPositiveButton("Download", (dialog, which) ->
                        startDownload(url, userAgent, contentDisposition, mimeType, fileName))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startDownload(String url, String userAgent, String contentDisposition,
                                String mimeType, String fileName) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimeType != null ? mimeType : guessMimeType(fileName));
            request.addRequestHeader("User-Agent", userAgent);
            request.setDescription("Downloading file");
            request.setTitle(fileName);
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                android.widget.Toast.makeText(activity, "Downloading " + fileName,
                        android.widget.Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            android.widget.Toast.makeText(activity, "Download failed: " + e.getMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
        // Note on "automatic installation after confirmation" for APKs: once the APK
        // finishes downloading, prompt ACTION_VIEW with a FileProvider URI and the
        // android.permission.REQUEST_INSTALL_PACKAGES permission (already declared in the
        // manifest) to launch the system installer — see MainActivity's download-complete
        // receiver hook if you wire one up; kept separate so plain file downloads don't
        // need install-package permission checks at all.
    }

    private String guessMimeType(String fileName) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(fileName);
        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        return type != null ? type : "application/octet-stream";
    }

    private long getAvailableInternalBytes() {
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        return stat.getAvailableBlocksLong() * stat.getBlockSizeLong();
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0 B";
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(bytes) / Math.log10(1024));
        digitGroups = Math.min(digitGroups, units.length - 1);
        return String.format(Locale.US, "%.1f %s", bytes / Math.pow(1024, digitGroups), units[digitGroups]);
    }
}
