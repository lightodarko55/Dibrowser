package com.dibrowser.app;

import android.content.Context;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.Set;

/**
 * Host-based ad/tracker blocker. Checked from WebViewClient.shouldInterceptRequest for
 * every request the page makes; a match returns an empty 200 response instead of letting
 * the request reach the network, which is what actually removes banner/video ad slots
 * instead of just leaving a blank box where the ad would have loaded.
 *
 * This is a small seed list so the project builds standalone. For real coverage, swap
 * loadSeedList() for loading a maintained list (e.g. a bundled copy of an EasyList-style
 * hosts file in assets/, one domain per line) — see loadFromAsset() below.
 */
public class AdBlocker {

    private final Set<String> blockedHosts = new HashSet<>();
    private static final WebResourceResponse EMPTY_RESPONSE =
            new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));

    public AdBlocker(Context context) {
        loadSeedList();
        loadFromAsset(context, "adblock_hosts.txt"); // optional; no-op if the asset isn't present
    }

    private void loadSeedList() {
        String[] seed = {
                "doubleclick.net", "googlesyndication.com", "googleadservices.com",
                "adservice.google.com", "pagead2.googlesyndication.com",
                "popads.net", "propellerads.com", "adnxs.com", "taboola.com",
                "outbrain.com", "mgid.com", "exoclick.com", "juicyads.com",
                "zedo.com", "adform.net", "criteo.com", "adroll.com",
                "revcontent.com", "smartadserver.com", "pubmatic.com",
                "rubiconproject.com", "openx.net", "media.net"
        };
        for (String h : seed) blockedHosts.add(h);
    }

    private void loadFromAsset(Context context, String assetName) {
        try (java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(context.getAssets().open(assetName)))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                blockedHosts.add(line);
            }
        } catch (Exception e) {
            // Asset not bundled — fine, we just run on the seed list above.
        }
    }

    /** O(labels) lookup: walks "a.b.c.com" -> "b.c.com" -> "c.com" in a hash set (fast enough for big lists on a TV). */
    public boolean isBlocked(String url) {
        if (url == null) return false;
        String host = hostOf(url);
        if (host == null) return false;
        while (true) {
            if (blockedHosts.contains(host)) return true;
            int dot = host.indexOf('.');
            if (dot < 0 || host.indexOf('.', dot + 1) < 0) return false;
            host = host.substring(dot + 1);
        }
    }

    private static String hostOf(String url) {
        int s = url.indexOf("://");
        if (s < 0) return null;
        s += 3;
        int e = s;
        int n = url.length();
        while (e < n) {
            char c = url.charAt(e);
            if (c == '/' || c == ':' || c == '?' || c == '#') break;
            e++;
        }
        if (e == s) return null;
        return url.substring(s, e).toLowerCase(java.util.Locale.US);
    }

    public WebResourceResponse blockedResponse() {
        return EMPTY_RESPONSE;
    }

    public int blockedHostCount() {
        return blockedHosts.size();
    }
}
