package com.dibrowser.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Main browser activity.
 *
 * UI layout (HiBrowser-style, landscape/TV friendly but works on phones):
 *  - left navigation rail: Home / Bookmark / History / IPTV / Settings. Shows icons only and
 *    expands to icons + labels while it has focus (D-pad) or when the logo is tapped.
 *  - HOME: search pill + round action buttons (voice, QR, incognito, downloads, clear, share)
 *    and a "Recommend" row of shortcut tiles.
 *  - BOOKMARK / HISTORY / IPTV: one shared list page.
 *  - SETTINGS: rounded setting cards, Feature Preference + Cursor dialogs.
 *  - BROWSER: full-screen WebView with a slim top bar (rail hidden).
 */
public class MainActivity extends AppCompatActivity {

    // pages
    private static final int HOME = 0, BOOKMARK = 1, HISTORY = 2, IPTV = 3, SETTINGS = 4, BROWSER = 5;
    private int page = HOME;

    private static final int FILECHOOSER_RESULTCODE = 1001;
    private static final int VOICE_RESULTCODE = 1002;

    // simple callbacks (java.util.function needs API 24; minSdk is 21)
    private interface BoolCallback { void onChanged(boolean v); }
    private interface IntCallback { void onPicked(int i); }
    private interface StrCallback { void onText(String s); }

    private Prefs prefs;

    // core views
    private LinearLayout navRail, navHeader;
    private LinearLayout[] navItems;
    private View pageHome, pageList, pageSettings, pageBrowser;
    private WebView webView;
    private EditText addressBar, homeSearch;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private ImageButton videoFab, btnBookmark, btnIncognito, btnMore;
    private View browserBar, giftBadge;
    private CursorView cursorView;

    // list page
    private TextView listTitle, listAction, listEmpty;
    private RecyclerView listRecycler;
    private Adapters.RowAdapter rowAdapter;
    private Adapters.TileAdapter tileAdapter;

    private LinearLayout settingsContainer;

    // browser engine pieces (unchanged logic from the original project)
    private VideoDetector videoDetector;
    private PopupBlockerChromeClient popupBlocker;
    private PopupGuard popupGuard;
    private boolean isTv;
    private final java.util.Set<String> sslAllowedHosts = new java.util.HashSet<>();
    private boolean sslDialogShowing;
    private AdBlocker adBlocker;
    private DownloadHandler downloadHandler;
    private PrivacyModeManager privacyMode;
    private String defaultUserAgent;

    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private final List<VideoDetector.VideoResult> foundVideos = new ArrayList<>();
    private final List<Prefs.Entry> iptvChannels = new ArrayList<>();
    private boolean iptvLoading = false;

    private boolean railExpanded = false;
    private boolean railPinned = false;

    private final ActivityResultLauncher<ScanOptions> qrLauncher =
            registerForActivityResult(new ScanContract(), result -> {
                if (result != null && result.getContents() != null) loadUrl(result.getContents());
            });

    private static final String[] RESTRICTED_KEYWORDS = {
            "porn", "xxx", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers", "onlyfans", "hentai"
    };

    // =========================================================================================
    // lifecycle
    // =========================================================================================
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new Prefs(this);
        adBlocker = new AdBlocker(this);
        downloadHandler = new DownloadHandler(this);
        privacyMode = new PrivacyModeManager();

        bindViews();
        setupRail();
        setupHome();
        setupBrowserBar();
        setupListPage();
        setupWebView();

        if (!handleIntent(getIntent())) {
            if (prefs.startOnLastPage() && !prefs.lastUrl().isEmpty()) {
                loadUrl(prefs.lastUrl());
            } else {
                showPage(HOME);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            loadUrl(i.getDataString());
            return true;
        }
        return false;
    }

    private void bindViews() {
        navRail = findViewById(R.id.nav_rail);
        navHeader = findViewById(R.id.nav_header);
        navItems = new LinearLayout[]{
                findViewById(R.id.nav_home), findViewById(R.id.nav_bookmark), findViewById(R.id.nav_history),
                findViewById(R.id.nav_iptv), findViewById(R.id.nav_settings)};

        pageHome = findViewById(R.id.page_home);
        pageList = findViewById(R.id.page_list);
        pageSettings = findViewById(R.id.page_settings);
        pageBrowser = findViewById(R.id.page_browser);

        homeSearch = findViewById(R.id.home_search);
        giftBadge = findViewById(R.id.gift_badge);
        btnIncognito = findViewById(R.id.btn_incognito);

        browserBar = findViewById(R.id.browser_bar);
        addressBar = findViewById(R.id.address_bar);
        btnBookmark = findViewById(R.id.btn_bookmark);
        btnMore = findViewById(R.id.btn_more);
        progressBar = findViewById(R.id.progress_bar);
        swipeRefresh = findViewById(R.id.swipe_refresh);
        webView = findViewById(R.id.webview);
        cursorView = findViewById(R.id.cursor_view);
        videoFab = findViewById(R.id.fab_videos);

        listTitle = findViewById(R.id.list_title);
        listAction = findViewById(R.id.list_action);
        listEmpty = findViewById(R.id.list_empty);
        listRecycler = findViewById(R.id.list_recycler);
        settingsContainer = findViewById(R.id.settings_container);
    }

    // =========================================================================================
    // navigation rail + page switching
    // =========================================================================================
    private void setupRail() {
        int[] pages = {HOME, BOOKMARK, HISTORY, IPTV, SETTINGS};
        for (int i = 0; i < navItems.length; i++) {
            final int target = pages[i];
            navItems[i].setOnClickListener(v -> showPage(target));
        }
        navHeader.setOnClickListener(v -> {
            railPinned = !railPinned;
            setRailExpanded(railPinned);
        });

        // Expand while focus is inside the rail (D-pad / remote), collapse when it leaves.
        findViewById(R.id.root).getViewTreeObserver().addOnGlobalFocusChangeListener((oldF, newF) ->
                setRailExpanded(railPinned || (newF != null && isDescendantOf(newF, navRail))));
        setRailExpanded(false);
    }

    private void setRailExpanded(boolean expanded) {
        if (expanded == railExpanded && navRail.getLayoutParams().width != 0 && navRail.getTag() != null) return;
        railExpanded = expanded;
        navRail.setTag("init");
        navRail.getLayoutParams().width = dp(expanded ? 236 : 80);
        List<LinearLayout> all = new ArrayList<>();
        all.add(navHeader);
        for (LinearLayout n : navItems) all.add(n);
        for (LinearLayout item : all) {
            item.getChildAt(1).setVisibility(expanded ? View.VISIBLE : View.GONE);
            item.setGravity(expanded ? (Gravity.START | Gravity.CENTER_VERTICAL) : Gravity.CENTER);
            int pad = expanded ? dp(16) : 0;
            item.setPaddingRelative(item == navHeader ? dp(4) : pad, 0, item == navHeader ? dp(4) : pad, 0);
        }
        navRail.requestLayout();
    }

    private void showPage(int p) {
        page = p;
        pageHome.setVisibility(p == HOME ? View.VISIBLE : View.GONE);
        pageList.setVisibility(p == BOOKMARK || p == HISTORY || p == IPTV ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(p == SETTINGS ? View.VISIBLE : View.GONE);
        pageBrowser.setVisibility(p == BROWSER ? View.VISIBLE : View.GONE);
        navRail.setVisibility(p == BROWSER ? View.GONE : View.VISIBLE);

        int[] order = {HOME, BOOKMARK, HISTORY, IPTV, SETTINGS};
        for (int i = 0; i < navItems.length; i++) navItems[i].setSelected(order[i] == p);

        if (p == HOME) refreshHome();
        else if (p == BOOKMARK) bindBookmarks();
        else if (p == HISTORY) bindHistory();
        else if (p == IPTV) bindIptv();
        else if (p == SETTINGS) buildSettings();
        else if (p == BROWSER) refreshBookmarkIcon();
        updateVideoFab();
        updateCursor();
    }

    private boolean isDescendantOf(View v, View parent) {
        while (v != null) {
            if (v == parent) return true;
            if (!(v.getParent() instanceof View)) return false;
            v = (View) v.getParent();
        }
        return false;
    }

    // =========================================================================================
    // HOME
    // =========================================================================================
    private void setupHome() {
        RecyclerView tiles = findViewById(R.id.home_tiles);
        tiles.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        tileAdapter = new Adapters.TileAdapter(new Adapters.TileListener() {
            @Override public void onTileClick(Prefs.Entry e) { loadUrl(e.url); }
            @Override public void onTileLongClick(Prefs.Entry e) { confirmRemoveShortcut(e); }
            @Override public void onAddClick() { showAddShortcutDialog(); }
        });
        tiles.setAdapter(tileAdapter);

        homeSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                String s = homeSearch.getText().toString().trim();
                homeSearch.setText("");
                loadUrl(s);
                return true;
            }
            return false;
        });
        // tapping the arrow at the end of the pill submits too
        homeSearch.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP
                    && ev.getRawX() >= homeSearch.getRight() - homeSearch.getTotalPaddingRight()
                    && homeSearch.getText().length() > 0) {
                String s = homeSearch.getText().toString().trim();
                homeSearch.setText("");
                loadUrl(s);
                return true;
            }
            return false;
        });

        findViewById(R.id.btn_mic).setOnClickListener(v -> startVoiceSearch());
        findViewById(R.id.btn_qr).setOnClickListener(v -> {
            ScanOptions o = new ScanOptions();
            o.setPrompt("Scan a QR code");
            o.setBeepEnabled(false);
            o.setOrientationLocked(false);
            qrLauncher.launch(o);
        });
        btnIncognito.setOnClickListener(v -> togglePrivacyMode());
        findViewById(R.id.btn_download).setOnClickListener(v -> {
            try {
                startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
            } catch (Exception e) {
                toast("No downloads app found");
            }
        });
        findViewById(R.id.btn_clear).setOnClickListener(v -> confirmClearData());
        findViewById(R.id.btn_gift).setOnClickListener(v -> {
            prefs.setGiftSeen();
            giftBadge.setVisibility(View.GONE);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, "Try " + getString(R.string.app_name) + " — a fast, ad-free browser.");
            startActivity(Intent.createChooser(send, "Share"));
        });
    }

    private void refreshHome() {
        tileAdapter.set(prefs.shortcuts());
        giftBadge.setVisibility(prefs.giftSeen() ? View.GONE : View.VISIBLE);
        btnIncognito.setSelected(privacyMode.isActive());
    }

    private void startVoiceSearch() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Search or say a website");
        try {
            startActivityForResult(i, VOICE_RESULTCODE);
        } catch (Exception e) {
            toast("Voice search isn't available on this device");
        }
    }

    private void showAddShortcutDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        final EditText name = new EditText(this);
        name.setHint("Name");
        name.setSingleLine(true);
        final EditText url = new EditText(this);
        url.setHint("https://example.com");
        url.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        url.setSingleLine(true);
        box.addView(name);
        box.addView(url);
        new AlertDialog.Builder(this)
                .setTitle("Add shortcut")
                .setView(box)
                .setPositiveButton("Add", (d, w) -> {
                    String n = name.getText().toString().trim();
                    String u = normalizeInput(url.getText().toString().trim());
                    if (n.isEmpty() || url.getText().toString().trim().isEmpty()) {
                        toast("Enter a name and a URL");
                        return;
                    }
                    List<Prefs.Entry> l = prefs.shortcuts();
                    l.add(new Prefs.Entry(n, u));
                    prefs.saveShortcuts(l);
                    refreshHome();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmRemoveShortcut(final Prefs.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Remove \"" + e.title + "\"?")
                .setPositiveButton("Remove", (d, w) -> {
                    List<Prefs.Entry> l = prefs.shortcuts();
                    for (int i = 0; i < l.size(); i++) {
                        if (l.get(i).url.equals(e.url) && l.get(i).title.equals(e.title)) { l.remove(i); break; }
                    }
                    prefs.saveShortcuts(l);
                    refreshHome();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // =========================================================================================
    // BOOKMARK / HISTORY / IPTV list page
    // =========================================================================================
    private void setupListPage() {
        listRecycler.setLayoutManager(new LinearLayoutManager(this));
        rowAdapter = new Adapters.RowAdapter();
        listRecycler.setAdapter(rowAdapter);
    }

    private void showList(String title, String action, Runnable actionClick, List<Adapters.Row> rows, String empty) {
        listTitle.setText(title);
        listAction.setText(action);
        listAction.setVisibility(action == null ? View.GONE : View.VISIBLE);
        listAction.setOnClickListener(v -> { if (actionClick != null) actionClick.run(); });
        rowAdapter.set(rows);
        listEmpty.setText(empty);
        listEmpty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
        listRecycler.setVisibility(rows.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void bindBookmarks() {
        final List<Prefs.Entry> l = prefs.bookmarks();
        List<Adapters.Row> rows = new ArrayList<>();
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            final Prefs.Entry e = l.get(i);
            rows.add(new Adapters.Row(e.title, e.url, R.drawable.ic_bookmark_filled,
                    () -> loadUrl(e.url),
                    () -> confirm("Delete bookmark?", e.title, "Delete", () -> {
                        List<Prefs.Entry> cur = prefs.bookmarks();
                        if (idx < cur.size()) cur.remove(idx);
                        prefs.saveBookmarks(cur);
                        bindBookmarks();
                    })));
        }
        showList("Bookmark", l.isEmpty() ? null : "Clear all",
                () -> confirm("Clear all bookmarks?", null, "Clear", () -> {
                    prefs.saveBookmarks(new ArrayList<Prefs.Entry>());
                    bindBookmarks();
                }), rows, "No bookmarks yet.\nOpen a page and tap the bookmark icon in the top bar.");
    }

    private void bindHistory() {
        final List<Prefs.Entry> l = prefs.history();
        List<Adapters.Row> rows = new ArrayList<>();
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            final Prefs.Entry e = l.get(i);
            rows.add(new Adapters.Row(e.title, e.url, R.drawable.ic_history,
                    () -> loadUrl(e.url),
                    () -> {
                        List<Prefs.Entry> cur = prefs.history();
                        if (idx < cur.size()) cur.remove(idx);
                        prefs.saveHistory(cur);
                        bindHistory();
                    }));
        }
        showList("History", l.isEmpty() ? null : "Clear all",
                () -> confirm("Clear browsing history?", null, "Clear", () -> {
                    prefs.clearHistory();
                    bindHistory();
                }), rows, "No history yet.");
    }

    private void bindIptv() {
        if (!prefs.iptvUrl().isEmpty() && iptvChannels.isEmpty() && !iptvLoading) loadPlaylist(prefs.iptvUrl());
        List<Adapters.Row> rows = new ArrayList<>();
        for (final Prefs.Entry c : iptvChannels) {
            rows.add(new Adapters.Row(c.title, c.url, R.drawable.ic_tv, () -> playUrl(c.url, c.title), null));
        }
        String empty = iptvLoading ? "Loading playlist…"
                : prefs.iptvUrl().isEmpty()
                ? "Add an M3U playlist link to watch live channels."
                : "No channels found in this playlist.";
        showList("IPTV", "Playlist", this::showPlaylistDialog, rows, empty);
    }

    private void showPlaylistDialog() {
        final EditText et = new EditText(this);
        et.setHint("https://example.com/playlist.m3u");
        et.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        et.setSingleLine(true);
        et.setText(prefs.iptvUrl());
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(et);
        new AlertDialog.Builder(this)
                .setTitle("M3U playlist")
                .setView(box)
                .setPositiveButton("Load", (d, w) -> {
                    String u = et.getText().toString().trim();
                    if (u.isEmpty()) return;
                    prefs.setIptvUrl(u);
                    loadPlaylist(u);
                })
                .setNeutralButton("Remove", (d, w) -> {
                    prefs.setIptvUrl("");
                    iptvChannels.clear();
                    bindIptv();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadPlaylist(final String url) {
        iptvLoading = true;
        iptvChannels.clear();
        if (page == IPTV) bindIptv();
        new Thread(() -> {
            final List<Prefs.Entry> out = new ArrayList<>();
            String error = null;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(20000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0");
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                String line, name = null;
                while ((line = r.readLine()) != null && out.size() < 5000) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    if (line.startsWith("#EXTINF")) {
                        int comma = line.lastIndexOf(',');
                        name = comma >= 0 ? line.substring(comma + 1).trim() : null;
                    } else if (!line.startsWith("#")) {
                        out.add(new Prefs.Entry(name == null || name.isEmpty() ? line : name, line));
                        name = null;
                    }
                }
                r.close();
            } catch (Exception e) {
                error = "Couldn't load playlist";
            }
            final String err = error;
            runOnUiThread(() -> {
                iptvLoading = false;
                iptvChannels.clear();
                iptvChannels.addAll(out);
                if (err != null) toast(err);
                if (page == IPTV) bindIptv();
            });
        }).start();
    }

    /** IPTV channels etc. (no page context). */
    private void playUrl(String url, String title) {
        playUrl(url, null, null, title, null);
    }

    /**
     * Opens the Smart Video Player. The page URL, user agent and cookies are forwarded because most
     * sites reject media requests that don't look like they come from the page itself (403).
     */
    private void playUrl(String url, String type, String pageUrl, String title, java.util.Map<String, String> headers) {
        if (prefs.smartPlayer()) {
            Intent intent = new Intent(this, VideoPlayerActivity.class);
            intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_URL, url);
            intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_TYPE, type);
            String t = title != null ? title : webView.getTitle();
            intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_TITLE, t == null ? "Video" : t);
            intent.putExtra(VideoPlayerActivity.EXTRA_PAGE_URL, pageUrl);
            intent.putExtra(VideoPlayerActivity.EXTRA_MAIN_PAGE, webView.getUrl());
            if (headers != null) intent.putExtra(VideoPlayerActivity.EXTRA_HEADERS, new java.util.HashMap<>(headers));
            intent.putExtra(VideoPlayerActivity.EXTRA_USER_AGENT, webView.getSettings().getUserAgentString());
            String cookies = null;
            try { cookies = CookieManager.getInstance().getCookie(url); } catch (Exception ignored) { }
            intent.putExtra(VideoPlayerActivity.EXTRA_COOKIES, cookies);
            startActivity(intent);
        } else {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(url), "video/*");
            try {
                startActivity(Intent.createChooser(intent, "Play with"));
            } catch (Exception e) {
                toast("No video player found");
            }
        }
    }

    // =========================================================================================
    // SETTINGS
    // =========================================================================================
    private View makeRow(ViewGroup parent, int icon, String title, String subtitle, View trailing, View.OnClickListener click) {
        View row = getLayoutInflater().inflate(R.layout.item_setting, parent, false);
        ImageView ic = row.findViewById(R.id.setting_icon);
        TextView t = row.findViewById(R.id.setting_title);
        TextView s = row.findViewById(R.id.setting_subtitle);
        FrameLayout tr = row.findViewById(R.id.setting_trailing);
        t.setText(title);
        if (subtitle != null) {
            s.setText(subtitle);
            s.setVisibility(View.VISIBLE);
        }
        if (icon != 0) {
            ic.setImageResource(icon);
        } else { // compact dialog row: no icon
            ic.setVisibility(View.GONE);
            ((ViewGroup.MarginLayoutParams) ((View) t.getParent()).getLayoutParams()).setMarginStart(0);
            row.setMinimumHeight(dp(64));
        }
        if (trailing != null) tr.addView(trailing);
        row.setOnClickListener(click);
        return row;
    }

    private SwitchCompat newSwitch(boolean checked) {
        SwitchCompat sw = (SwitchCompat) getLayoutInflater().inflate(R.layout.view_switch, null);
        sw.setChecked(checked);
        return sw;
    }

    private void addSwitchRow(ViewGroup parent, int icon, String title, boolean init, final BoolCallback cb) {
        final SwitchCompat sw = newSwitch(init);
        View row = makeRow(parent, icon, title, null, sw, v -> sw.toggle());
        sw.setOnCheckedChangeListener((b, checked) -> cb.onChanged(checked));
        parent.addView(row);
    }

    private void addHeader(ViewGroup parent, String text) {
        TextView h = new TextView(this);
        h.setText(text);
        h.setTextColor(0xFFFFFFFF);
        h.setTextSize(18);
        h.setTypeface(h.getTypeface(), android.graphics.Typeface.BOLD);
        h.setPaddingRelative(dp(4), dp(20), 0, dp(8));
        parent.addView(h);
    }

    private View engineBadge(Prefs.Engine e) {
        TextView b = new TextView(this);
        b.setText(e.letter);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(e.color);
        b.setTextSize(20);
        b.setTypeface(b.getTypeface(), android.graphics.Typeface.BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFFFFFFFF);
        b.setBackground(g);
        b.setLayoutParams(new FrameLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    private void buildSettings() {
        ViewGroup c = settingsContainer;
        c.removeAllViews();

        addHeader(c, "General");

        c.addView(makeRow(c, R.drawable.ic_home, "On Startup",
                prefs.startOnLastPage() ? "Continue where you left off" : "Home page", null, v ->
                showChoice("On Startup", new String[]{"Home page", "Continue where you left off"},
                        prefs.startOnLastPage() ? 1 : 0, i -> {
                            prefs.setStartOnLastPage(i == 1);
                            buildSettings();
                        })));

        c.addView(makeRow(c, R.drawable.ic_tune, "Customize Home Page", null, null, v -> showCustomizeHome()));

        c.addView(makeRow(c, R.drawable.ic_search_engine, "Search Engine", prefs.engine().name,
                engineBadge(prefs.engine()), v -> {
                    String[] names = new String[Prefs.ENGINES.length];
                    for (int i = 0; i < names.length; i++) names[i] = Prefs.ENGINES[i].name;
                    showChoice("Search Engine", names, prefs.engineIndex(), i -> {
                        prefs.setEngineIndex(i);
                        buildSettings();
                    });
                }));

        c.addView(makeRow(c, R.drawable.ic_user_agent, "Change User Agent",
                Prefs.USER_AGENTS[prefs.userAgentIndex()][0], null, v -> {
                    String[] names = new String[Prefs.USER_AGENTS.length];
                    for (int i = 0; i < names.length; i++) names[i] = Prefs.USER_AGENTS[i][0];
                    showChoice("Change User Agent", names, prefs.userAgentIndex(), i -> {
                        prefs.setUserAgentIndex(i);
                        applyUserAgent();
                        buildSettings();
                    });
                }));

        Locale loc = Locale.getDefault();
        c.addView(makeRow(c, R.drawable.ic_language, "Language",
                loc.getDisplayLanguage(loc) + " (System Default)", null, v -> openLanguageSettings()));

        // Age-related lock: PIN protected
        final SwitchCompat ageSwitch = newSwitch(prefs.ageLock());
        c.addView(makeRow(c, R.drawable.ic_lock, "Age-related lock", null, ageSwitch, v -> {
            if (!prefs.ageLock()) {
                askPin("Set a 4-digit PIN", pin -> {
                    if (pin.length() == 4) {
                        prefs.setAgeLock(true, pin);
                        ageSwitch.setChecked(true);
                    } else {
                        toast("PIN must be 4 digits");
                    }
                });
            } else {
                askPin("Enter PIN to turn the lock off", pin -> {
                    if (pin.equals(prefs.agePin())) {
                        prefs.setAgeLock(false, "");
                        ageSwitch.setChecked(false);
                    } else {
                        toast("Wrong PIN");
                    }
                });
            }
        }));

        c.addView(makeRow(c, R.drawable.ic_toggle, "Feature Preference", null, null, v -> showFeaturePreference()));
        c.addView(makeRow(c, R.drawable.ic_cursor, "Cursor settings", null, null, v -> showCursorSettings()));

        addHeader(c, "Security and Privacy");
        addSwitchRow(c, R.drawable.ic_shield, "Ad blocker", prefs.adBlock(), on -> prefs.setAdBlock(on));
        addSwitchRow(c, R.drawable.ic_close, "Block popups", prefs.popupBlock(), on -> {
            prefs.setPopupBlock(on);
            syncPopupBlocking();
        });
        addSwitchRow(c, R.drawable.ic_shield, "Block third-party redirects", prefs.redirectBlock(), on -> {
            prefs.setRedirectBlock(on);
            syncPopupBlocking();
        });
        final SwitchCompat incog = newSwitch(privacyMode.isActive());
        c.addView(makeRow(c, R.drawable.ic_incognito, "Incognito mode", null, incog, v -> {
            togglePrivacyMode();
            incog.setChecked(privacyMode.isActive());
        }));
        c.addView(makeRow(c, R.drawable.ic_delete, "Clear browsing data", null, null, v -> confirmClearData()));

        addHeader(c, "About");
        String ver = "1.0";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (pi.versionName != null) ver = pi.versionName;
        } catch (Exception ignored) {
        }
        c.addView(makeRow(c, R.drawable.ic_info, getString(R.string.app_name), "Version " + ver, null, null));
    }

    private void showFeaturePreference() {
        Dialog d = newCardDialog("Feature Preference");
        LinearLayout body = d.findViewById(R.id.dialog_body);
        addSwitchRow(body, 0, "Video Control", prefs.videoControl(), on -> {
            prefs.setVideoControl(on);
            updateVideoFab();
        });
        addSwitchRow(body, 0, "Smart Video Player", prefs.smartPlayer(), on -> prefs.setSmartPlayer(on));
        addSwitchRow(body, 0, "Dark Mode", prefs.darkMode(), on -> {
            prefs.setDarkMode(on);
            applyDarkMode();
        });
        addSwitchRow(body, 0, "Ad Block", prefs.adBlock(), on -> {
            prefs.setAdBlock(on);
            if (page == SETTINGS) buildSettings();
        });
        addSwitchRow(body, 0, "Popup Block", prefs.popupBlock(), on -> {
            prefs.setPopupBlock(on);
            syncPopupBlocking();
            if (page == SETTINGS) buildSettings();
        });
        addSwitchRow(body, 0, "Third-party Redirect Block", prefs.redirectBlock(), on -> {
            prefs.setRedirectBlock(on);
            syncPopupBlocking();
            if (page == SETTINGS) buildSettings();
        });
        d.show();
    }

    private void showCursorSettings() {
        final Dialog d = newCardDialog("Cursor settings");
        LinearLayout body = d.findViewById(R.id.dialog_body);
        addSwitchRow(body, 0, "Enable cursor (D-pad mouse)", prefs.cursorEnabled(), on -> {
            prefs.setCursorEnabled(on);
            updateCursor();
        });
        body.addView(makeRow(body, 0, "Cursor speed", Prefs.CURSOR_SPEED_NAMES[prefs.cursorSpeedIndex()], null, v ->
                showChoice("Cursor speed", Prefs.CURSOR_SPEED_NAMES, prefs.cursorSpeedIndex(), i -> {
                    prefs.setCursorSpeedIndex(i);
                    ((TextView) v.findViewById(R.id.setting_subtitle)).setText(Prefs.CURSOR_SPEED_NAMES[i]);
                })));
        d.show();
    }

    private void showCustomizeHome() {
        showChoice("Customize Home Page", new String[]{"Add shortcut", "Remove shortcut", "Reset to default"}, -1, i -> {
            if (i == 0) {
                showAddShortcutDialog();
            } else if (i == 1) {
                final List<Prefs.Entry> l = prefs.shortcuts();
                if (l.isEmpty()) { toast("No shortcuts to remove"); return; }
                String[] names = new String[l.size()];
                for (int k = 0; k < names.length; k++) names[k] = l.get(k).title;
                new AlertDialog.Builder(this)
                        .setTitle("Remove shortcut")
                        .setItems(names, (dd, which) -> {
                            l.remove(which);
                            prefs.saveShortcuts(l);
                            toast("Removed");
                        })
                        .setNegativeButton("Close", null)
                        .show();
            } else {
                prefs.resetShortcuts();
                toast("Home page reset");
            }
        });
    }

    private void openLanguageSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                startActivity(new Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.parse("package:" + getPackageName())));
            } else {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
            }
        } catch (Exception e) {
            toast("Language settings not available");
        }
    }

    // ---- dialog helpers ---------------------------------------------------------------------
    private Dialog newCardDialog(String title) {
        Dialog d = new Dialog(this, R.style.Theme_MyBrowser_CardDialog);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(R.layout.dialog_card);
        ((TextView) d.findViewById(R.id.dialog_title)).setText(title);
        int w = Math.min(getResources().getDisplayMetrics().widthPixels - dp(48), dp(560));
        d.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
        return d;
    }

    private void showChoice(String title, String[] items, int checked, final IntCallback cb) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(items, checked, (d, which) -> {
                    d.dismiss();
                    cb.onPicked(which);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirm(String title, @Nullable String msg, String positive, final Runnable onYes) {
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(title);
        if (msg != null) b.setMessage(msg);
        b.setPositiveButton(positive, (d, w) -> onYes.run())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askPin(String title, final StrCallback cb) {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        et.setGravity(Gravity.CENTER);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(et);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("OK", (d, w) -> cb.onText(et.getText().toString()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmClearData() {
        confirm("Clear browsing data?", "History, cache, cookies and site data will be deleted.", "Clear", () -> {
            prefs.clearHistory();
            webView.clearHistory();
            webView.clearCache(true);
            webView.clearFormData();
            CookieManager.getInstance().removeAllCookies(null);
            WebStorage.getInstance().deleteAllData();
            toast("Browsing data cleared");
        });
    }

    // =========================================================================================
    // BROWSER bar
    // =========================================================================================
    private void setupBrowserBar() {
        findViewById(R.id.btn_home).setOnClickListener(v -> showPage(HOME));
        findViewById(R.id.btn_back).setOnClickListener(v -> goBackFast());
        findViewById(R.id.btn_forward).setOnClickListener(v -> goForwardFast());
        findViewById(R.id.btn_reload).setOnClickListener(v -> webView.reload());
        btnBookmark.setOnClickListener(v -> toggleBookmark());
        btnMore.setOnClickListener(v -> showBrowserMenu());
        videoFab.setOnClickListener(v -> showVideoListDialog());

        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                loadUrl(addressBar.getText().toString().trim());
                return true;
            }
            return false;
        });
        swipeRefresh.setOnRefreshListener(() -> webView.reload());
    }

    private void showBrowserMenu() {
        PopupMenu pm = new PopupMenu(this, btnMore);
        pm.getMenuInflater().inflate(R.menu.browser_menu, pm.getMenu());
        MenuItem v = pm.getMenu().findItem(R.id.action_videos);
        v.setVisible(!foundVideos.isEmpty());
        v.setTitle("Videos (" + foundVideos.size() + ")");
        pm.getMenu().findItem(R.id.action_popup_toggle)
                .setTitle("Popup blocking: " + (popupBlocker.isPopupBlockingEnabled() ? "ON" : "OFF"));
        pm.getMenu().findItem(R.id.action_redirect_toggle)
                .setTitle("Redirect blocking: " + (prefs.redirectBlock() ? "ON" : "OFF"));
        pm.getMenu().findItem(R.id.action_privacy_toggle)
                .setTitle(privacyMode.isActive() ? "Turn off incognito mode" : "Turn on incognito mode");
        pm.setOnMenuItemClickListener(this::onMenuItem);
        pm.show();
    }

    private boolean onMenuItem(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_videos) {
            showVideoListDialog();
        } else if (id == R.id.action_popup_toggle) {
            boolean on = !prefs.popupBlock();
            prefs.setPopupBlock(on);
            syncPopupBlocking();
            toast("Popup blocking: " + (on ? "ON" : "OFF"));
        } else if (id == R.id.action_redirect_toggle) {
            boolean on = !prefs.redirectBlock();
            prefs.setRedirectBlock(on);
            syncPopupBlocking();
            toast("Redirect blocking: " + (on ? "ON" : "OFF"));
        } else if (id == R.id.action_privacy_toggle) {
            togglePrivacyMode();
        } else if (id == R.id.action_privacy_history) {
            showPrivacyHistoryDialog();
        } else if (id == R.id.action_settings) {
            showPage(SETTINGS);
        } else {
            return false;
        }
        return true;
    }

    private void toggleBookmark() {
        String url = webView.getUrl();
        if (url == null || url.startsWith("data:") || url.equals("about:blank")) return;
        List<Prefs.Entry> l = prefs.bookmarks();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).url.equals(url)) {
                l.remove(i);
                prefs.saveBookmarks(l);
                refreshBookmarkIcon();
                toast("Bookmark removed");
                return;
            }
        }
        String title = webView.getTitle();
        l.add(0, new Prefs.Entry(title == null || title.isEmpty() ? url : title, url));
        prefs.saveBookmarks(l);
        refreshBookmarkIcon();
        toast("Bookmarked");
    }

    private void refreshBookmarkIcon() {
        String url = webView.getUrl();
        btnBookmark.setImageResource(url != null && prefs.isBookmarked(url)
                ? R.drawable.ic_bookmark_filled : R.drawable.ic_bookmark);
    }

    private void updateAddress(String url) {
        if (url == null || url.startsWith("data:")) return;
        if (!addressBar.hasFocus()) addressBar.setText(url);
    }

    // =========================================================================================
    // WebView
    // =========================================================================================
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        isTv = ((android.app.UiModeManager) getSystemService(UI_MODE_SERVICE)).getCurrentModeType()
                == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
                || !getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        if (isTv) {
            // TV tuning: no pinch-zoom / pull-to-refresh / overscroll glow, GPU layer, no pre-raster
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            swipeRefresh.setEnabled(false);
        }
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        defaultUserAgent = settings.getUserAgentString();
        applyUserAgent();
        applyDarkMode();

        videoDetector = new VideoDetector(this, result -> runOnUiThread(() -> onVideoDetected(result)));
        webView.addJavascriptInterface(videoDetector.getJsInterface(), VideoDetector.JS_INTERFACE_NAME);
        videoDetector.install(webView);

        popupGuard = new PopupGuard(what -> toast("Popup blocked"));
        popupGuard.setAdCheck(url -> prefs.adBlock() && adBlocker.isBlocked(url));
        popupGuard.install(webView);

        popupBlocker = new PopupBlockerChromeClient(this, popupGuard, new PopupBlockerChromeClient.Callback() {
            @Override
            public void onPopupBlocked(String url) {
                toast("Popup blocked");
            }

            @Override
            public void onRedirectBlocked(String url) {
                toast("Third-party redirect blocked");
            }

            @Override
            public boolean isAdUrl(String url) {
                return adBlocker.isBlocked(url);
            }

            @Override
            public void onProgressChanged(int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onShowFileChooser(android.webkit.ValueCallback<Uri[]> callback) {
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Choose file"), FILECHOOSER_RESULTCODE);
            }
        });
        webView.setWebChromeClient(popupBlocker);
        syncPopupBlocking();

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                downloadHandler.onDownloadStart(url, userAgent, contentDisposition, mimeType, contentLength));

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    // strict popup / forced-redirect guard: no user tap behind it -> refuse
                    if (popupGuard.shouldBlockNavigation(view, request)
                            || (prefs.popupBlock() && !request.hasGesture() && !request.isRedirect()
                                && request.isForMainFrame() && adBlocker.isBlocked(url))) {
                        toast(prefs.redirectBlock() ? "Third-party redirect blocked" : "Redirect blocked");
                        return true;
                    }
                    if (isRestricted(url)) {
                        showBlockedPage();
                        return true;
                    }
                    return false;
                }
                // app schemes (intent://, market://, mailto:, tel: ...): a jump to another app the
                // user never asked for is a redirect hijack - only open with a real user gesture
                if (request.isForMainFrame() && !request.hasGesture()
                        && (prefs.popupBlock() || prefs.redirectBlock())) {
                    toast("Redirect blocked");
                    return true;
                }
                try {
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    startActivity(intent);
                } catch (Exception e) {
                    // nothing can handle it
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                popupGuard.onPageStarted(view);
                updateAddress(url);
                progressBar.setVisibility(View.VISIBLE);
                privacyMode.recordVisit(url);
                foundVideos.clear();
                videoDetector.reset();
                updateVideoFab();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT); // back used cache-first; normal loads fetch fresh
                popupGuard.onPageStarted(view); // fallback injection (no-op when document-start scripts work)
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                updateAddress(url);
                refreshBookmarkIcon();
                if (url != null && url.startsWith("http")) {
                    if (!privacyMode.isActive()) prefs.addHistory(view.getTitle(), url);
                    prefs.setLastUrl(url);
                }
                videoDetector.scan(webView);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Sub-resources (ads, trackers, images, embeds) with a bad certificate are simply
                // dropped - asking about them is what caused the popup on every page load.
                String pageUrl = view.getUrl();
                String errUrl = error.getUrl();
                final String host = Uri.parse(errUrl == null ? "" : errUrl).getHost();
                String pageHost = pageUrl == null ? null : Uri.parse(pageUrl).getHost();
                boolean mainFrame = pageHost == null || (host != null && host.equalsIgnoreCase(pageHost));
                if (host != null && sslAllowedHosts.contains(host)) {
                    handler.proceed();
                    return;
                }
                if (!mainFrame || sslDialogShowing) {
                    handler.cancel();
                    return;
                }
                sslDialogShowing = true;
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Connection not private")
                        .setMessage((host == null ? "This site" : host) + "'s certificate is not valid. Continue anyway?")
                        .setPositiveButton("Continue", (dialog, which) -> {
                            if (host != null) sslAllowedHosts.add(host); // ask once per site
                            handler.proceed();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> handler.cancel())
                        .setOnDismissListener(dialog -> sslDialogShowing = false)
                        .show();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (prefs.adBlock() && adBlocker.isBlocked(url)) {
                    return adBlocker.blockedResponse();
                }
                videoDetector.onResourceRequested(url, request.getRequestHeaders());
                return super.shouldInterceptRequest(view, request);
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void applyDarkMode() {
        boolean on = prefs.darkMode();
        WebSettings s = webView.getSettings();
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, on);
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, on ? WebSettingsCompat.FORCE_DARK_ON : WebSettingsCompat.FORCE_DARK_OFF);
        }
    }

    private void applyUserAgent() {
        String ua = Prefs.USER_AGENTS[prefs.userAgentIndex()][1];
        webView.getSettings().setUserAgentString(ua.isEmpty() ? defaultUserAgent : ua);
        if (page == BROWSER && webView.getUrl() != null) webView.reload();
    }

    private void syncPopupBlocking() {
        boolean popups = prefs.popupBlock();
        boolean redirects = prefs.redirectBlock();
        if (popupBlocker != null) popupBlocker.setPopupBlockingEnabled(popups);
        if (popupGuard != null) popupGuard.configure(popups, redirects);
        if (webView != null) webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(!popups);
    }

    private boolean isRestricted(String url) {
        if (!prefs.ageLock()) return false;
        String l = url.toLowerCase(Locale.ROOT);
        for (String k : RESTRICTED_KEYWORDS) if (l.contains(k)) return true;
        return false;
    }

    private void showBlockedPage() {
        showPage(BROWSER);
        String html = "<html><body style='background:#15171C;color:#fff;font-family:sans-serif;text-align:center;padding-top:20vh'>"
                + "<h2>Blocked</h2><p style='color:#9A9CA3'>The age-related lock is on.</p></body></html>";
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        addressBar.setText("");
    }

    /**
     * Back without a network reload: history navigation is served from the cache first (and the
     * WebView restores the scroll position), so the previous page appears instantly, even offline.
     */
    private void goBackFast() {
        if (!webView.canGoBack()) return;
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.goBack();
    }

    private void goForwardFast() {
        if (!webView.canGoForward()) return;
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.goForward();
    }

    private void loadUrl(String input) {
        if (TextUtils.isEmpty(input)) return;
        String url = normalizeInput(input.trim());
        if (isRestricted(url)) {
            showBlockedPage();
            return;
        }
        showPage(BROWSER);
        webView.loadUrl(url);
    }

    private String normalizeInput(String input) {
        if (input.startsWith("http://") || input.startsWith("https://")) return input;
        if (input.contains(".") && !input.contains(" ")) return "https://" + input;
        return prefs.engine().searchUrl + Uri.encode(input);
    }

    // =========================================================================================
    // video list / incognito
    // =========================================================================================
    private void onVideoDetected(VideoDetector.VideoResult result) {
        if (result.url == null || result.url.startsWith("blob:") || result.url.startsWith("data:")) return;
        if (!prefs.videoDetectEnabled(currentHost())) return;
        for (int i = 0; i < foundVideos.size(); i++) {
            VideoDetector.VideoResult existing = foundVideos.get(i);
            if (existing.url.equals(result.url)) {
                // the network sniffer's headers are the page's real ones: prefer them
                if (result.headers != null && result.headers.containsKey("Origin")
                        && (existing.headers == null || !existing.headers.containsKey("Origin"))
                        || result.headers != null && result.headers.containsKey("Referer")
                        && (existing.headers == null || !existing.headers.containsKey("Referer"))) {
                    foundVideos.set(i, new VideoDetector.VideoResult(existing.url, existing.type, existing.pageUrl, result.headers));
                }
                return;
            }
        }
        // remember which page the video came from: the player needs it as the Referer header
        foundVideos.add(new VideoDetector.VideoResult(result.url, result.type,
                result.pageUrl != null && result.pageUrl.startsWith("http") ? result.pageUrl : webView.getUrl(), result.headers));
        updateVideoFab();
        if (prefs.videoControl() && foundVideos.size() == 1) toast("Video found - tap the play button");
    }

    private String currentHost() {
        try {
            String h = Uri.parse(webView.getUrl()).getHost();
            return h == null ? "" : h.replaceFirst("^www\\.", "");
        } catch (Exception e) {
            return "";
        }
    }

    private void updateVideoFab() {
        videoFab.setVisibility(prefs.videoControl() && page == BROWSER
                && (!foundVideos.isEmpty() || !prefs.videoDetectEnabled(currentHost()))
                ? View.VISIBLE : View.GONE);
    }

    /** "Select Video to Play" popup: one card per detected video, tap to open the Smart Player. */
    private void showVideoListDialog() {
        final String host = currentHost();
        final Dialog d = newCardDialog("Select Video to Play");
        LinearLayout body = d.findViewById(R.id.dialog_body);

        // domain card: "example.com / Enabled for this domain" + switch
        View card = getLayoutInflater().inflate(R.layout.item_video_domain, body, false);
        ((TextView) card.findViewById(R.id.domain_name)).setText(host.isEmpty() ? "This site" : host);
        final TextView state = card.findViewById(R.id.domain_state);
        final SwitchCompat sw = card.findViewById(R.id.domain_switch);
        boolean enabled = prefs.videoDetectEnabled(host);
        sw.setChecked(enabled);
        state.setText(enabled ? "Enabled for this domain" : "Disabled for this domain");
        sw.setOnCheckedChangeListener((b, on) -> {
            prefs.setVideoDetectEnabled(host, on);
            state.setText(on ? "Enabled for this domain" : "Disabled for this domain");
            if (!on) {
                foundVideos.clear();
                updateVideoFab();
            }
        });
        card.setOnClickListener(v -> sw.toggle());
        body.addView(card);

        if (foundVideos.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No videos detected on this page yet.\nPlay a video on the page and it will show up here.");
            empty.setTextColor(0xFF9A9CA3);
            empty.setTextSize(14);
            empty.setPadding(dp(4), dp(16), dp(4), dp(8));
            body.addView(empty);
            d.show();
            return;
        }

        View divider = new View(this);
        divider.setBackgroundColor(0xFF3A3C42);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dlp.setMargins(0, dp(2), 0, dp(12));
        body.addView(divider, dlp);

        String pageTitle = webView.getTitle();
        if (pageTitle == null || pageTitle.isEmpty()) pageTitle = host.isEmpty() ? "Video" : host;
        boolean first = true;
        for (final VideoDetector.VideoResult r : foundVideos) {
            View row = getLayoutInflater().inflate(R.layout.item_video, body, false);
            ((TextView) row.findViewById(R.id.video_title)).setText(pageTitle);
            ((TextView) row.findViewById(R.id.video_quality)).setText("\u25A0 " + r.type.toUpperCase(Locale.ROOT));
            ((TextView) row.findViewById(R.id.video_url)).setText(r.url);
            row.setOnClickListener(v -> {
                d.dismiss();
                playUrl(r.url, r.type, r.pageUrl, null, r.headers);
            });
            body.addView(row);
            if (first) { row.requestFocus(); first = false; }
        }
        d.show();
    }

    private void togglePrivacyMode() {
        if (privacyMode.isActive()) {
            privacyMode.disable(webView);
            toast("Incognito mode off — browsing data cleared");
        } else {
            privacyMode.enable(webView);
            toast("You are now in incognito mode");
        }
        btnIncognito.setSelected(privacyMode.isActive());
    }

    private void showPrivacyHistoryDialog() {
        final List<String> history = privacyMode.getSessionHistory();
        if (history.isEmpty()) {
            toast(privacyMode.isActive() ? "No incognito history yet" : "Incognito mode is off");
            return;
        }
        String[] items = history.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Incognito history")
                .setItems(items, (dialog, which) -> loadUrl(history.get(which)))
                .setNeutralButton("Clear all", (dialog, which) -> {
                    history.clear();
                    toast("Incognito history cleared");
                })
                .setNegativeButton("Close", null)
                .show();
    }

    // =========================================================================================
    // D-pad cursor (Android TV / remote)
    // =========================================================================================
    private void updateCursor() {
        cursorView.setVisibility(prefs.cursorEnabled() && page == BROWSER ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (page == BROWSER && prefs.cursorEnabled() && handleCursorKey(e)) return true;
        return super.dispatchKeyEvent(e);
    }

    private boolean handleCursorKey(KeyEvent e) {
        View f = getCurrentFocus();
        // while the top bar (or the video button) has focus, normal D-pad focus navigation applies
        if (f != null && (isDescendantOf(f, browserBar) || f == videoFab)) return false;
        // let the on-screen keyboard / dialogs keep their keys
        if (f instanceof EditText) return false;

        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        switch (e.getKeyCode()) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT: {
                if (!down) return true;
                float step = Prefs.CURSOR_SPEEDS[prefs.cursorSpeedIndex()]
                        * getResources().getDisplayMetrics().density
                        * (1f + Math.min(e.getRepeatCount(), 12) / 4f);
                int k = e.getKeyCode();
                float dx = k == KeyEvent.KEYCODE_DPAD_LEFT ? -step : k == KeyEvent.KEYCODE_DPAD_RIGHT ? step : 0;
                float dy = k == KeyEvent.KEYCODE_DPAD_UP ? -step : k == KeyEvent.KEYCODE_DPAD_DOWN ? step : 0;
                boolean moved = cursorView.moveBy(dx, dy);
                if (!moved && dy != 0) {
                    if (dy < 0 && !webView.canScrollVertically(-1)) {
                        addressBar.requestFocus(); // pushed past the top: hand focus to the bar
                    } else {
                        webView.scrollBy(0, (int) (dy * 2));
                    }
                }
                return true;
            }
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (down && e.getRepeatCount() == 0) sendTap(MotionEvent.ACTION_DOWN);
                else if (!down) sendTap(MotionEvent.ACTION_UP);
                return true;
            default:
                return false;
        }
    }

    private void sendTap(int action) {
        if (action == MotionEvent.ACTION_DOWN) webView.requestFocus();
        long now = SystemClock.uptimeMillis();
        MotionEvent m = MotionEvent.obtain(now, now, action, cursorView.pointerX(), cursorView.pointerY(), 0);
        m.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        webView.dispatchTouchEvent(m);
        m.recycle();
    }

    // =========================================================================================
    // misc
    // =========================================================================================
    @Override
    public void onBackPressed() {
        if (page == BROWSER) {
            if (webView.canGoBack()) goBackFast();
            else showPage(HOME);
        } else if (page != HOME) {
            showPage(HOME);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == FILECHOOSER_RESULTCODE) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == VOICE_RESULTCODE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) loadUrl(r.get(0));
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();   // stop JS timers / media while in background
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_LOW && webView != null) webView.clearCache(false);
    }

    @Override
    protected void onDestroy() {
        if (videoDetector != null) videoDetector.release();
        if (privacyMode != null && privacyMode.isActive()) privacyMode.disable(webView);
        webView.destroy();
        super.onDestroy();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
