package com.dibrowser.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/**
 * On-screen mouse pointer for D-pad / TV-remote control. It is purely visual; MainActivity moves
 * it with the arrow keys and turns DPAD_CENTER into a tap at the pointer position.
 */
public class CursorView extends View {

    private float x = -1, y = -1;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();

    public CursorView(Context c) { this(c, null); }

    public CursorView(Context c, AttributeSet a) {
        super(c, a);
        setFocusable(false);
        setClickable(false);
        fill.setColor(0xFFFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFF000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        stroke.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (x < 0 || y < 0) {
            x = w / 2f;
            y = h / 2f;
        }
        x = Math.min(x, w);
        y = Math.min(y, h);
    }

    public float pointerX() { return x; }
    public float pointerY() { return y; }

    /** Moves the pointer, clamped to the view. Returns true if it actually moved. */
    public boolean moveBy(float dx, float dy) {
        float nx = Math.max(0, Math.min(getWidth() - 1, x + dx));
        float ny = Math.max(0, Math.min(getHeight() - 1, y + dy));
        boolean moved = nx != x || ny != y;
        if (moved) {
            // redraw only the small area around the old and new pointer (cheap on TV GPUs)
            int pad = (int) (30 * getResources().getDisplayMetrics().density);
            invalidate((int) x - 4, (int) y - 4, (int) x + pad, (int) y + pad);
            x = nx;
            y = ny;
            invalidate((int) x - 4, (int) y - 4, (int) x + pad, (int) y + pad);
        }
        return moved;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (x < 0) return;
        float s = getResources().getDisplayMetrics().density;
        arrow.reset();
        arrow.moveTo(x, y);
        arrow.lineTo(x, y + 20 * s);
        arrow.lineTo(x + 5 * s, y + 15.5f * s);
        arrow.lineTo(x + 9 * s, y + 23 * s);
        arrow.lineTo(x + 12 * s, y + 21.5f * s);
        arrow.lineTo(x + 8 * s, y + 14.5f * s);
        arrow.lineTo(x + 14 * s, y + 14.5f * s);
        arrow.close();
        c.drawPath(arrow, fill);
        c.drawPath(arrow, stroke);
    }
}
