package com.dibrowser.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Smart Video Player – styled after HiBrowser.
 * Reads Referer, Cookie, User-Agent from the intent so HLS/DASH CDN streams
 * that need those headers are authenticated correctly.
 */
@OptIn(markerClass = UnstableApi.class)
public class VideoPlayerActivity extends AppCompatActivity {

    public static final String EXTRA_VIDEO_URL   = "extra_video_url";
    public static final String EXTRA_VIDEO_TITLE = "extra_video_title";
    public static final String EXTRA_VIDEO_TYPE  = "extra_video_type";
    public static final String EXTRA_PAGE_URL    = "extra_page_url";
    public static final String EXTRA_USER_AGENT  = "extra_user_agent";
    public static final String EXTRA_HEADERS = "extra_headers";
    public static final String EXTRA_COOKIES     = "extra_cookies";
    public static final String EXTRA_MAIN_PAGE   = "extra_main_page";

    private ExoPlayer player;
    private PlayerView playerView;
    private DefaultTrackSelector trackSelector;

    private Button qualityButton;
    private Button audioButton;
    private Button captionsButton;
    private Button speedButton;
    private TextView titleView;

    private boolean captionsEnabled = false;
    private float currentSpeed = 1.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_video_player);

        playerView    = findViewById(R.id.player_view);
        qualityButton = findViewById(R.id.btn_quality);
        audioButton   = findViewById(R.id.btn_audio);
        captionsButton= findViewById(R.id.btn_captions);
        speedButton   = findViewById(R.id.btn_speed);
        titleView     = findViewById(R.id.player_title);

        // Back button
        View backBtn = findViewById(R.id.btn_player_back);
        if (backBtn != null) backBtn.setOnClickListener(v -> onBackPressed());

        Intent intent = getIntent();
        String url     = intent.getStringExtra(EXTRA_VIDEO_URL);
        String title   = intent.getStringExtra(EXTRA_VIDEO_TITLE);
        String type    = intent.getStringExtra(EXTRA_VIDEO_TYPE);
        String pageUrl = intent.getStringExtra(EXTRA_PAGE_URL);
        String ua      = intent.getStringExtra(EXTRA_USER_AGENT);
        String cookies = intent.getStringExtra(EXTRA_COOKIES);

        if (url == null || url.isEmpty()) {
            Toast.makeText(this, "No video URL provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (titleView != null) titleView.setText(title != null ? title : "Video");

        goImmersive();
        if (isProgressive(url, type)) {
            startProgressive();          // mp4 / webm / mkv / flv ... : own retry ladder + fallbacks
        } else {
            initPlayer(url, type, pageUrl, ua, cookies); // HLS / DASH / Smooth: original 1.1 path
        }

        qualityButton.setOnClickListener(v -> showQualityDialog());
        audioButton.setOnClickListener(v -> showAudioDialog());
        captionsButton.setOnClickListener(v -> toggleCaptions());
        speedButton.setOnClickListener(v -> showSpeedDialog());
        final View topBar = findViewById(R.id.player_top_bar);
        if (topBar != null) {
            playerView.setControllerVisibilityListener(
                    (PlayerView.ControllerVisibilityListener) visibility -> topBar.setVisibility(visibility));
        }
        View gear = findViewById(R.id.btn_player_settings);
        if (gear != null) gear.setOnClickListener(v -> showSettingsDialog());
    }

    /** Gear menu: Quality / Audio / Subtitles / Speed, each with its current value. */
    private void showSettingsDialog() {
        if (player == null) return;
        String q = qualityButton.getText().toString();
        String a = audioButton.getText().toString();
        String cc = captionsButton.getText().toString().replace("CC: ", "");
        String sp = currentSpeed == 1.0f ? "Normal" : currentSpeed + "x";
        final String[] items = {
                "Quality    \u2022  " + (q.equals("Quality") ? "Auto" : q),
                "Audio    \u2022  " + (a.equals("Audio") ? "Auto" : a),
                "Subtitles    \u2022  " + cc,
                "Speed    \u2022  " + sp
        };
        new AlertDialog.Builder(this)
                .setTitle("Player settings")
                .setItems(items, (d, which) -> {
                    if (which == 0) showQualityDialog();
                    else if (which == 1) showAudioDialog();
                    else if (which == 2) toggleCaptions();
                    else showSpeedDialog();
                })
                .show();
    }

    // ─── Player init ────────────────────────────────────────────────────────

    private int headerVariant = 0; // 0 all, 1 no cookie, 2 no origin, 3 root referer, 4 none

    private void initPlayer(String url, String type, String pageUrl, String ua, String cookies) {
        if (player != null) {
            player.release();
            player = null;
        }
        // Build HTTP data source with all browser headers so CDN streams work
        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory();

        String resolvedUa = (ua != null && !ua.isEmpty())
                ? ua
                : "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36";
        httpFactory.setUserAgent(resolvedUa);
        httpFactory.setAllowCrossProtocolRedirects(true);
        httpFactory.setConnectTimeoutMs(15000);
        httpFactory.setReadTimeoutMs(15000);

        Map<String, String> headers = new HashMap<>();
        // Preferred: the exact Referer/Origin the page's own player sent for this stream
        // (usually an embed/iframe host, not the address-bar page - using the wrong one gives HTTP 403/500).
        @SuppressWarnings("unchecked")
        Map<String, String> captured = (Map<String, String>) getIntent().getSerializableExtra(EXTRA_HEADERS);
        if (captured != null) {
            for (Map.Entry<String, String> e : captured.entrySet()) {
                if (e.getKey().equalsIgnoreCase("User-Agent")) {
                    httpFactory.setUserAgent(e.getValue());
                } else if (e.getValue() != null && !e.getValue().isEmpty()) {
                    headers.put(e.getKey(), e.getValue());
                }
            }
        }
        if (!headers.containsKey("Referer") && pageUrl != null && !pageUrl.isEmpty()) {
            headers.put("Referer", pageUrl);
        }
        if (cookies != null && !cookies.isEmpty()) {
            headers.put("Cookie", cookies);
        }
        // Retry ladder used by onPlayerError: some CDNs answer 403/500 to unexpected headers.
        if (headerVariant >= 1) headers.remove("Cookie");
        if (headerVariant >= 2) headers.remove("Origin");
        if (headerVariant == 3 && headers.containsKey("Referer")) {
            try { // Referer = just the site root, some CDNs only accept that
                Uri r = Uri.parse(headers.get("Referer"));
                headers.put("Referer", r.getScheme() + "://" + r.getAuthority() + "/");
            } catch (Exception ignored) { }
        }
        if (headerVariant >= 4) headers.clear();
        if (!headers.isEmpty()) {
            httpFactory.setDefaultRequestProperties(headers);
        }

        trackSelector = new DefaultTrackSelector(this);
        // Disable text tracks by default (user can enable via CC button)
        trackSelector.setParameters(
                trackSelector.buildUponParameters()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
        );

        player = new ExoPlayer.Builder(this)
                .setTrackSelector(trackSelector)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(this)
                        .setDataSourceFactory(httpFactory))
                .build();

        playerView.setPlayer(player);
        playerView.setControllerShowTimeoutMs(3500);
        playerView.setKeepContentOnPlayerReset(true);

        // Build MediaItem with explicit MIME type hint for HLS/DASH
        MediaItem.Builder itemBuilder = new MediaItem.Builder().setUri(url);
        if (type != null) {
            if (type.contains("m3u8") || type.equalsIgnoreCase("hls")) {
                itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8);
            } else if (type.contains("mpd") || type.equalsIgnoreCase("dash")) {
                itemBuilder.setMimeType(MimeTypes.APPLICATION_MPD);
            }
        } else if (url.contains(".m3u8")) {
            itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8);
        } else if (url.contains(".mpd")) {
            itemBuilder.setMimeType(MimeTypes.APPLICATION_MPD);
        }
        if (type != null && type.equalsIgnoreCase("smooth")) itemBuilder.setMimeType(MimeTypes.APPLICATION_SS);
        player.setMediaItem(itemBuilder.build());
        player.setPlayWhenReady(true);
        player.prepare();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                int httpCode = -1;
                Throwable cause = error.getCause();
                while (cause != null) {
                    if (cause instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                        httpCode = ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) cause).responseCode;
                        break;
                    }
                    cause = cause.getCause();
                }
                if (httpCode > 0 && headerVariant < 4) {
                    headerVariant++;
                    Toast.makeText(VideoPlayerActivity.this, "Retrying with different headers...", Toast.LENGTH_SHORT).show();
                    playerView.post(() -> initPlayer(getIntent().getStringExtra(EXTRA_VIDEO_URL),
                            getIntent().getStringExtra(EXTRA_VIDEO_TYPE), getIntent().getStringExtra(EXTRA_PAGE_URL),
                            getIntent().getStringExtra(EXTRA_USER_AGENT), getIntent().getStringExtra(EXTRA_COOKIES)));
                    return;
                }
                final String msg = httpCode > 0
                        ? "Cannot play video (HTTP " + httpCode + ")\nTry opening in external app."
                        : "Cannot play this video.\n" + error.getErrorCodeName();

                new AlertDialog.Builder(VideoPlayerActivity.this)
                        .setTitle("Playback Error")
                        .setMessage(msg)
                        .setPositiveButton("Open in other app", (d, w) -> openExternal(
                                getIntent().getStringExtra(EXTRA_VIDEO_URL)))
                        .setNegativeButton("Close", (d, w) -> finish())
                        .show();
            }

            @Override
            public void onTracksChanged(Tracks tracks) {
                boolean multiQuality = countVideoRenditions(tracks) > 1;
                boolean multiAudio   = countAudioGroups(tracks) > 1;
                boolean hasSubs      = hasAnyTrack(tracks, C.TRACK_TYPE_TEXT);

                qualityButton.setEnabled(multiQuality);
                qualityButton.setAlpha(multiQuality ? 1f : 0.45f);
                audioButton.setEnabled(multiAudio);
                audioButton.setAlpha(multiAudio ? 1f : 0.45f);
                captionsButton.setEnabled(hasSubs);
                captionsButton.setAlpha(hasSubs ? 1f : 0.45f);
            }
        });
    }

    // ─── Plain files (MP4 / WebM / MKV / FLV / 3GP ...) ───────────────────────
    // HLS / DASH / Smooth keep the original initPlayer() path above. Plain files get their own ladder:
    //   * different network stacks (HttpURLConnection, then OkHttp: HTTP/2 + modern TLS),
    //   * different User-Agents (servers filter on UA / "wv"), Referer and cookie combinations,
    //   * then an embedded Chromium <video> player, then Chromium opening the file directly.

    private static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private static final class ProgStep {
        final boolean okHttp;
        final String ua;
        final Map<String, String> headers;
        ProgStep(boolean okHttp, String ua, Map<String, String> headers) {
            this.okHttp = okHttp; this.ua = ua; this.headers = headers;
        }
        String signature() {
            return okHttp + "|" + ua + "|" + new java.util.TreeMap<String, String>(headers);
        }
    }

    private final List<ProgStep> progPlan = new ArrayList<>();
    private int progIndex = 0;
    private String formatOverride = null;     // "hls" when a "plain file" link is really a playlist
    private boolean progEverReady = false;
    private int progMidRetries = 0;
    private long progResumeMs = 0;
    private String lastProgError = "";
    private boolean webFallbackActive = false;
    private WebView fallbackWeb;

    /** True for plain files. HLS and DASH keep their original, unchanged code path. */
    private static boolean isProgressive(String url, String type) {
        String t = type == null ? "" : type.toLowerCase(Locale.ROOT);
        String u = url == null ? "" : url.toLowerCase(Locale.ROOT);
        if (t.contains("m3u8") || t.equals("hls") || t.contains("mpd") || t.equals("dash") || t.equals("smooth")) return false;
        if (u.startsWith("rtsp:") || u.startsWith("rtmp")) return false;
        return !(u.contains(".m3u8") || u.contains(".mpd") || u.contains(".ism/manifest") || u.contains(".isml/manifest"));
    }

    private static String rootOf(String url) {
        try {
            Uri u = Uri.parse(url);
            if (u.getScheme() == null || u.getAuthority() == null) return null;
            return u.getScheme() + "://" + u.getAuthority() + "/";
        } catch (Exception e) {
            return null;
        }
    }

    private static String cleanUa(String ua) {
        // "; wv" / "Version/4.0" mark an embedded WebView, which some CDNs refuse for media files
        return ua.replace("; wv", "").replaceAll(" Version/\\d+\\.\\d+", "");
    }

    private static Map<String, String> progHeaders(String referer, String cookie, boolean fetchMeta) {
        Map<String, String> m = new HashMap<>();
        m.put("Accept", "*/*");                       // HttpURLConnection's default Accept is HTML-ish
        m.put("Accept-Language", "en-US,en;q=0.9");
        if (fetchMeta) {                              // what Chromium sends for a <video> element
            m.put("Sec-Fetch-Dest", "video");
            m.put("Sec-Fetch-Mode", "no-cors");
            m.put("Sec-Fetch-Site", "cross-site");
        }
        if (referer != null) m.put("Referer", referer);
        if (cookie != null && !cookie.isEmpty()) m.put("Cookie", cookie);
        return m;
    }

    private void buildProgPlan() {
        progPlan.clear();
        final Intent in = getIntent();
        final String url = in.getStringExtra(EXTRA_VIDEO_URL);
        String pageUrl = in.getStringExtra(EXTRA_PAGE_URL);
        String mainPage = in.getStringExtra(EXTRA_MAIN_PAGE);
        String cookie = in.getStringExtra(EXTRA_COOKIES);
        String ua0 = in.getStringExtra(EXTRA_USER_AGENT);
        if (ua0 == null || ua0.isEmpty()) ua0 = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36";

        String capRef = null;
        @SuppressWarnings("unchecked")
        Map<String, String> cap = (Map<String, String>) in.getSerializableExtra(EXTRA_HEADERS);
        if (cap != null) {
            for (Map.Entry<String, String> e : cap.entrySet()) {
                if (e.getKey() == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                if (e.getKey().equalsIgnoreCase("Referer")) capRef = e.getValue();
                else if (e.getKey().equalsIgnoreCase("User-Agent")) ua0 = e.getValue();
            }
        }
        // the media URL itself (old sniffer behaviour) is never a valid Referer
        if (capRef != null && capRef.equals(url)) capRef = null;
        if (pageUrl != null && (!pageUrl.startsWith("http") || pageUrl.equals(url))) pageUrl = null;
        if (mainPage != null && !mainPage.startsWith("http")) mainPage = null;
        String ref = capRef != null ? capRef : (pageUrl != null ? pageUrl : mainPage);
        String clean = cleanUa(ua0);

        List<ProgStep> s = new ArrayList<>();
        s.add(new ProgStep(false, ua0,     progHeaders(ref, cookie, false)));
        s.add(new ProgStep(true,  clean,   progHeaders(ref, cookie, true)));
        s.add(new ProgStep(false, clean,   progHeaders(ref, null, false)));
        s.add(new ProgStep(true,  DESKTOP_UA, progHeaders(ref == null ? null : rootOf(ref), cookie, true)));
        if (mainPage != null && !mainPage.equals(ref))
            s.add(new ProgStep(false, clean, progHeaders(mainPage, cookie, false)));
        s.add(new ProgStep(true,  clean,   progHeaders(rootOf(url), null, false)));
        s.add(new ProgStep(false, clean,   progHeaders(null, null, false)));
        s.add(new ProgStep(false, null,    new HashMap<String, String>()));   // completely bare request
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (ProgStep p : s) if (seen.add(p.signature())) progPlan.add(p);
    }

    private void startProgressive() {
        if (progPlan.isEmpty()) buildProgPlan();
        launchProgStep();
    }

    private void launchProgStep() {
        if (isFinishing() || isDestroyed() || webFallbackActive) return;
        if (player != null) { player.release(); player = null; }
        final ProgStep st = progPlan.get(progIndex);
        progEverReady = false;
        final String url = getIntent().getStringExtra(EXTRA_VIDEO_URL);

        androidx.media3.datasource.DataSource.Factory dsf;
        if (st.okHttp) {
            okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                    .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .build();
            androidx.media3.datasource.okhttp.OkHttpDataSource.Factory f =
                    new androidx.media3.datasource.okhttp.OkHttpDataSource.Factory(client);
            if (st.ua != null) f.setUserAgent(st.ua);
            if (!st.headers.isEmpty()) f.setDefaultRequestProperties(st.headers);
            dsf = f;
        } else {
            DefaultHttpDataSource.Factory f = new DefaultHttpDataSource.Factory();
            if (st.ua != null) f.setUserAgent(st.ua);
            f.setAllowCrossProtocolRedirects(true);
            f.setConnectTimeoutMs(15000);
            f.setReadTimeoutMs(20000);
            if (!st.headers.isEmpty()) f.setDefaultRequestProperties(st.headers);
            dsf = f;
        }

        trackSelector = new DefaultTrackSelector(this);
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !captionsEnabled).build());
        player = new ExoPlayer.Builder(this)
                .setTrackSelector(trackSelector)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(dsf))
                .build();
        final ExoPlayer me = player;
        playerView.setPlayer(player);
        playerView.setControllerShowTimeoutMs(3500);
        playerView.setKeepContentOnPlayerReset(true);

        MediaItem.Builder ib = new MediaItem.Builder().setUri(url);
        if ("hls".equals(formatOverride)) ib.setMimeType(MimeTypes.APPLICATION_M3U8);
        player.setMediaItem(ib.build());
        if (progResumeMs > 0) player.seekTo(progResumeMs);
        if (currentSpeed != 1.0f) player.setPlaybackSpeed(currentSpeed);
        player.setPlayWhenReady(true);
        player.prepare();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) progEverReady = true;
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (me != player) return;
                onProgError(error);
            }

            @Override
            public void onTracksChanged(Tracks tracks) {
                boolean multiQuality = countVideoRenditions(tracks) > 1;
                boolean multiAudio   = countAudioGroups(tracks) > 1;
                boolean hasSubs      = hasAnyTrack(tracks, C.TRACK_TYPE_TEXT);
                qualityButton.setEnabled(multiQuality);
                qualityButton.setAlpha(multiQuality ? 1f : 0.45f);
                audioButton.setEnabled(multiAudio);
                audioButton.setAlpha(multiAudio ? 1f : 0.45f);
                captionsButton.setEnabled(hasSubs);
                captionsButton.setAlpha(hasSubs ? 1f : 0.45f);
            }
        });
    }

    private static int httpCodeOf(Throwable t) {
        while (t != null) {
            if (t instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                return ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) t).responseCode;
            }
            t = t.getCause();
        }
        return -1;
    }

    private static boolean isFormatError(PlaybackException e) {
        int c = e.errorCode;
        if (c == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
                || c == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                || c == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED
                || c == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED) return true;
        Throwable t = e;
        while (t != null) {
            if (t instanceof UnrecognizedInputFormatException) return true;
            t = t.getCause();
        }
        return false;
    }

    private void onProgError(PlaybackException error) {
        if (player != null) {
            long pos = player.getCurrentPosition();
            if (pos > 0) progResumeMs = pos;
        }
        int http = httpCodeOf(error);
        lastProgError = (http > 0 ? "HTTP " + http : error.getErrorCodeName());

        // died in the middle of playing (e.g. a Range request got refused): resume the same step twice
        if (progEverReady && progMidRetries < 2) {
            progMidRetries++;
            playerView.post(this::launchProgStep);
            return;
        }
        // the server answered, but the bytes are not a known video file: maybe it is really a playlist
        if (http <= 0 && isFormatError(error) && !"hls".equals(formatOverride)) {
            formatOverride = "hls";
            playerView.post(this::launchProgStep);
            return;
        }
        formatOverride = null;
        if (progIndex + 1 < progPlan.size()) {
            progIndex++;
            progMidRetries = 0;
            Toast.makeText(this, "Retrying with different headers... (" + (progIndex + 1) + "/" + progPlan.size()
                    + ", " + lastProgError + ")", Toast.LENGTH_SHORT).show();
            playerView.post(this::launchProgStep);
            return;
        }
        playerView.post(this::startWebFallback);
    }

    private final class FallbackBridge {
        @android.webkit.JavascriptInterface
        public void onVideoError(final int code) {
            runOnUiThread(() -> loadDirectInWeb("media error " + code));
        }
    }

    /** Stage 1 of the compatibility player: an HTML5 <video> on a page-like origin (same cookies / UA as the browser). */
    @android.annotation.SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void startWebFallback() {
        if (isFinishing() || webFallbackActive) return;
        webFallbackActive = true;
        Toast.makeText(this, "Switching to compatibility player...", Toast.LENGTH_SHORT).show();
        if (player != null) { player.release(); player = null; }
        playerView.setVisibility(View.GONE);
        final View topBar = findViewById(R.id.player_top_bar);
        if (topBar != null) topBar.setVisibility(View.VISIBLE);
        View gear = findViewById(R.id.btn_player_settings);
        if (gear != null) gear.setVisibility(View.GONE);

        final String url = getIntent().getStringExtra(EXTRA_VIDEO_URL);
        fallbackWeb = new WebView(this);
        FrameLayout root = (FrameLayout) playerView.getParent();
        root.addView(fallbackWeb, 1, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        WebSettings ws = fallbackWeb.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        String ua = getIntent().getStringExtra(EXTRA_USER_AGENT);
        if (ua != null && !ua.isEmpty()) ws.setUserAgentString(ua);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(fallbackWeb, true);
        fallbackWeb.setBackgroundColor(0xFF000000);
        fallbackWeb.setWebChromeClient(new WebChromeClient());
        fallbackWeb.addJavascriptInterface(new FallbackBridge(), "AndroidFallback");
        fallbackWeb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                return true;
            }
        });

        String safe = url.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;");
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>html,body{margin:0;height:100%;background:#000}video{width:100%;height:100%;background:#000}</style>"
                + "</head><body><video id='v' src=\"" + safe + "\" controls autoplay playsinline></video>"
                + "<script>var v=document.getElementById('v');"
                + "v.addEventListener('error',function(){try{AndroidFallback.onVideoError(v.error?v.error.code:0);}catch(e){}});"
                + "v.play&&v.play().catch(function(){});</script></body></html>";
        String base = getIntent().getStringExtra(EXTRA_MAIN_PAGE);
        if (base == null || !base.startsWith("http")) base = getIntent().getStringExtra(EXTRA_PAGE_URL);
        if (base == null || !base.startsWith("http") || base.equals(url)) base = rootOf(url);
        fallbackWeb.loadDataWithBaseURL(base, html, "text/html", "UTF-8", null);
    }

    /** Stage 2: let Chromium open the file URL itself (document request) with the page as Referer. */
    private boolean directTried = false;

    private void loadDirectInWeb(String why) {
        if (fallbackWeb == null || isFinishing()) return;
        final String url = getIntent().getStringExtra(EXTRA_VIDEO_URL);
        if (directTried) {
            showFinalError(why);
            return;
        }
        directTried = true;
        fallbackWeb.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedHttpError(WebView view, android.webkit.WebResourceRequest request,
                                            android.webkit.WebResourceResponse errorResponse) {
                if (request.isForMainFrame()) {
                    final int code = errorResponse.getStatusCode();
                    runOnUiThread(() -> showFinalError("HTTP " + code));
                }
            }
        });
        Map<String, String> extra = new HashMap<>();
        String ref = getIntent().getStringExtra(EXTRA_MAIN_PAGE);
        if (ref == null || !ref.startsWith("http")) ref = getIntent().getStringExtra(EXTRA_PAGE_URL);
        if (ref != null && ref.startsWith("http") && !ref.equals(url)) extra.put("Referer", ref);
        fallbackWeb.loadUrl(url, extra);
    }

    private void showFinalError(String webWhy) {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this)
                .setTitle("Playback Error")
                .setMessage("This video could not be played.\nPlayer: " + lastProgError + "\nBrowser engine: " + webWhy
                        + "\n\nThe link may have expired - reload the page and tap the video again, or open it in another app.")
                .setPositiveButton("Open in other app", (d, w) -> openExternal(getIntent().getStringExtra(EXTRA_VIDEO_URL)))
                .setNegativeButton("Close", (d, w) -> finish())
                .show();
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private int countVideoRenditions(Tracks tracks) {
        int n = 0;
        for (Tracks.Group g : tracks.getGroups())
            if (g.getType() == C.TRACK_TYPE_VIDEO) n += g.length;
        return n;
    }

    private int countAudioGroups(Tracks tracks) {
        int n = 0;
        for (Tracks.Group g : tracks.getGroups())
            if (g.getType() == C.TRACK_TYPE_AUDIO) n += g.length;
        return n;
    }

    private boolean hasAnyTrack(Tracks tracks, int type) {
        for (Tracks.Group g : tracks.getGroups())
            if (g.getType() == type && g.length > 0) return true;
        return false;
    }

    private void openExternal(String url) {
        if (url == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No app found to open this video", Toast.LENGTH_SHORT).show();
        }
    }

    // ─── Quality ─────────────────────────────────────────────────────────────

    private void showQualityDialog() {
        List<String> labels = new ArrayList<>();
        List<TrackSelectionOverride> overrides = new ArrayList<>();
        labels.add("Auto (adaptive)");
        overrides.add(null);

        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_VIDEO) continue;
            for (int i = 0; i < g.length; i++) {
                androidx.media3.common.Format fmt = g.getTrackFormat(i);
                labels.add(fmtVideo(fmt));
                overrides.add(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
            }
        }

        if (labels.size() <= 1) {
            Toast.makeText(this, "This stream has only one quality level", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Video Quality")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    DefaultTrackSelector.Parameters.Builder b = trackSelector.buildUponParameters();
                    b.clearOverridesOfType(C.TRACK_TYPE_VIDEO);
                    if (overrides.get(which) != null) b.addOverride(overrides.get(which));
                    trackSelector.setParameters(b);
                    qualityButton.setText(which == 0 ? "Quality" : labels.get(which).split(" ")[0]);
                })
                .show();
    }

    private String fmtVideo(androidx.media3.common.Format f) {
        String res = f.height > 0 ? f.height + "p" : "?p";
        String bps = f.bitrate > 0 ? " · " + (f.bitrate / 1000) + " kbps" : "";
        return res + bps;
    }

    // ─── Audio ───────────────────────────────────────────────────────────────

    private void showAudioDialog() {
        List<String> labels = new ArrayList<>();
        List<TrackSelectionOverride> overrides = new ArrayList<>();

        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int i = 0; i < g.length; i++) {
                androidx.media3.common.Format fmt = g.getTrackFormat(i);
                String lang = fmt.language != null ? fmt.language.toUpperCase(Locale.ROOT) : "Default";
                String lbl  = fmt.label != null ? fmt.label : lang;
                if (fmt.channelCount > 0) lbl += " · " + fmt.channelCount + "ch";
                labels.add(lbl);
                overrides.add(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
            }
        }

        if (labels.isEmpty()) {
            Toast.makeText(this, "No alternate audio tracks in this stream", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Audio Track")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    DefaultTrackSelector.Parameters.Builder b = trackSelector.buildUponParameters();
                    b.clearOverridesOfType(C.TRACK_TYPE_AUDIO);
                    b.addOverride(overrides.get(which));
                    trackSelector.setParameters(b);
                    audioButton.setText(labels.get(which).split(" ·")[0]);
                })
                .show();
    }

    // ─── Captions ────────────────────────────────────────────────────────────

    private void toggleCaptions() {
        if (!captionsEnabled) {
            Tracks tracks = player.getCurrentTracks();
            List<String> labels = new ArrayList<>();
            List<TrackSelectionOverride> overrides = new ArrayList<>();
            for (Tracks.Group g : tracks.getGroups()) {
                if (g.getType() != C.TRACK_TYPE_TEXT) continue;
                for (int i = 0; i < g.length; i++) {
                    androidx.media3.common.Format f = g.getTrackFormat(i);
                    String lang = f.language != null ? f.language : "Unknown";
                    labels.add(f.label != null ? f.label : lang.toUpperCase(Locale.ROOT));
                    overrides.add(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
                }
            }
            if (overrides.isEmpty()) {
                Toast.makeText(this, "No subtitles available", Toast.LENGTH_SHORT).show();
                return;
            }
            if (overrides.size() == 1) {
                applySubtitle(overrides.get(0));
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Subtitle Language")
                        .setItems(labels.toArray(new String[0]), (d, w) -> applySubtitle(overrides.get(w)))
                        .show();
            }
        } else {
            trackSelector.setParameters(trackSelector.buildUponParameters()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true));
            captionsEnabled = false;
            captionsButton.setText("CC: Off");
        }
    }

    private void applySubtitle(TrackSelectionOverride override) {
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                .addOverride(override));
        captionsEnabled = true;
        captionsButton.setText("CC: On");
    }

    // ─── Speed ───────────────────────────────────────────────────────────────

    private void showSpeedDialog() {
        float[] speeds = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};
        String[] labels = {"0.25×", "0.5×", "0.75×", "1× (Normal)", "1.25×", "1.5×", "1.75×", "2×"};

        int current = 3;
        for (int i = 0; i < speeds.length; i++) {
            if (Math.abs(speeds[i] - currentSpeed) < 0.01f) { current = i; break; }
        }

        new AlertDialog.Builder(this)
                .setTitle("Playback Speed")
                .setSingleChoiceItems(labels, current, (d, which) -> {
                    currentSpeed = speeds[which];
                    player.setPlaybackSpeed(currentSpeed);
                    speedButton.setText(currentSpeed == 1.0f ? "1×" : labels[which]);
                    d.dismiss();
                })
                .show();
    }

    // ─── Immersive mode ───────────────────────────────────────────────────────

    private void goImmersive() {
        WindowInsetsControllerCompat ctrl =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        ctrl.hide(WindowInsetsCompat.Type.systemBars());
        ctrl.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    // ─── Lifecycle ───────────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        goImmersive();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        if (fallbackWeb != null) fallbackWeb.onPause();
    }

    @Override
    protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        if (fallbackWeb != null) {
            try { fallbackWeb.loadUrl("about:blank"); fallbackWeb.destroy(); } catch (Exception ignored) { }
            fallbackWeb = null;
        }
        super.onDestroy();
    }
}
